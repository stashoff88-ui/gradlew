package me.francisek.client.gui;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import me.francisek.client.config.ConfigManager;
import me.francisek.client.config.ModConfig;
import me.francisek.client.feature.Feature;
import me.francisek.client.feature.movement.Flight;
import me.francisek.client.feature.movement.ReachAdjustment;
import me.francisek.client.feature.visuals.EntityESP;
import me.francisek.client.feature.visuals.EntityInfoOverlay;

/**
 * The per-feature settings screen opened from a {@link ModuleButton}'s "..." button. The
 * exact set of controls shown depends on which {@link Feature} was opened; each branch below
 * corresponds directly to one "Settings" section from the project spec (ESP, Entity Info,
 * Flight, Reach).
 */
public class SettingsScreen extends Screen {

	private static final int WIDTH = 260;
	private static final int ROW_HEIGHT = 24;

	private final Screen parent;
	private final Feature feature;
	private final ConfigManager configManager;
	private final List<ColorPickerComponent> colorPickers = new ArrayList<>();

	public SettingsScreen(Screen parent, Feature feature, ConfigManager configManager) {
		super(Text.translatable(feature.nameTranslationKey()));
		this.parent = parent;
		this.feature = feature;
		this.configManager = configManager;
	}

	@Override
	protected void init() {
		int x = (width - WIDTH) / 2;
		int y = height / 8;

		if (feature instanceof EntityESP) {
			y = buildEspSettings(x, y);
		} else if (feature instanceof EntityInfoOverlay) {
			y = buildEntityInfoSettings(x, y);
		} else if (feature instanceof Flight) {
			y = buildFlightSettings(x, y);
		} else if (feature instanceof ReachAdjustment reach) {
			y = buildReachSettings(x, y, reach);
		}

		addDrawableChild(ButtonWidget.builder(Text.translatable("francisekclient.format.literal", "Done"), button -> close())
				.dimensions(x, y + 10, WIDTH, 20)
				.build());
	}

	private int buildEspSettings(int x, int y) {
		ModConfig.EspSettings esp = configManager.config().esp;

		addDrawableChild(ToggleComponent.create(x, y, WIDTH, Text.translatable("francisekclient.format.literal", "Players"), () -> esp.players, v -> esp.players = v));
		y += ROW_HEIGHT;
		addDrawableChild(ToggleComponent.create(x, y, WIDTH, Text.translatable("francisekclient.format.literal", "Hostile"), () -> esp.hostile, v -> esp.hostile = v));
		y += ROW_HEIGHT;
		addDrawableChild(ToggleComponent.create(x, y, WIDTH, Text.translatable("francisekclient.format.literal", "Passive"), () -> esp.passive, v -> esp.passive = v));
		y += ROW_HEIGHT;
		addDrawableChild(ToggleComponent.create(x, y, WIDTH, Text.translatable("francisekclient.format.literal", "Neutral"), () -> esp.neutral, v -> esp.neutral = v));
		y += ROW_HEIGHT;
		addDrawableChild(ToggleComponent.create(x, y, WIDTH, Text.translatable("francisekclient.format.literal", "Villagers"), () -> esp.villagers, v -> esp.villagers = v));
		y += ROW_HEIGHT;
		addDrawableChild(ToggleComponent.create(x, y, WIDTH, Text.translatable("francisekclient.format.literal", "Other"), () -> esp.other, v -> esp.other = v));
		y += ROW_HEIGHT;

		addDrawableChild(ButtonWidget.builder(renderModeLabel(esp.renderMode), button -> {
					esp.renderMode = nextRenderMode(esp.renderMode);
					button.setMessage(renderModeLabel(esp.renderMode));
				})
				.dimensions(x, y, WIDTH, 20)
				.build());
		y += ROW_HEIGHT;

		addDrawableChild(new SliderComponent(x, y, WIDTH, 20, 4, 512, () -> esp.maxDistance,
				v -> esp.maxDistance = v, 1.0, v -> Text.translatable("francisekclient.format.literal", "Max Distance: " + (int) v + "m")));
		y += ROW_HEIGHT;

		addDrawableChild(new SliderComponent(x, y, WIDTH, 20, 0.5, 8.0, () -> esp.lineWidth,
				v -> esp.lineWidth = (float) v, 0.5, v -> Text.translatable("francisekclient.format.literal", String.format("Line Width: %.1f", v))));
		y += ROW_HEIGHT + 4;

		y = addColorPicker(x, y, "Player Color", () -> esp.playerColor, v -> esp.playerColor = v);
		y = addColorPicker(x, y, "Hostile Color", () -> esp.hostileColor, v -> esp.hostileColor = v);
		y = addColorPicker(x, y, "Passive Color", () -> esp.passiveColor, v -> esp.passiveColor = v);
		y = addColorPicker(x, y, "Neutral Color", () -> esp.neutralColor, v -> esp.neutralColor = v);
		y = addColorPicker(x, y, "Villager Color", () -> esp.villagerColor, v -> esp.villagerColor = v);
		y = addColorPicker(x, y, "Other Color", () -> esp.otherColor, v -> esp.otherColor = v);

		return y;
	}

	private int buildEntityInfoSettings(int x, int y) {
		ModConfig.EntityInfoSettings info = configManager.config().entityInfo;

		addDrawableChild(ToggleComponent.create(x, y, WIDTH, Text.translatable("francisekclient.format.literal", "Show Name"), () -> info.showName, v -> info.showName = v));
		y += ROW_HEIGHT;
		addDrawableChild(ToggleComponent.create(x, y, WIDTH, Text.translatable("francisekclient.format.literal", "Show Health"), () -> info.showHealth, v -> info.showHealth = v));
		y += ROW_HEIGHT;
		addDrawableChild(ToggleComponent.create(x, y, WIDTH, Text.translatable("francisekclient.format.literal", "Show Distance"), () -> info.showDistance, v -> info.showDistance = v));
		y += ROW_HEIGHT;
		addDrawableChild(ToggleComponent.create(x, y, WIDTH, Text.translatable("francisekclient.format.literal", "Background"), () -> info.background, v -> info.background = v));
		y += ROW_HEIGHT;

		addDrawableChild(new SliderComponent(x, y, WIDTH, 20, 4, 256, () -> info.maxDistance,
				v -> info.maxDistance = v, 1.0, v -> Text.translatable("francisekclient.format.literal", "Max Distance: " + (int) v + "m")));
		y += ROW_HEIGHT;
		addDrawableChild(new SliderComponent(x, y, WIDTH, 20, 0.25, 3.0, () -> info.textScale,
				v -> info.textScale = (float) v, 0.05, v -> Text.translatable("francisekclient.format.literal", String.format("Text Scale: %.2f", v))));
		y += ROW_HEIGHT;
		addDrawableChild(new SliderComponent(x, y, WIDTH, 20, 0.0, 1.0, () -> info.backgroundOpacity,
				v -> info.backgroundOpacity = (float) v, 0.05, v -> Text.translatable("francisekclient.format.literal", String.format("Background Opacity: %.0f%%", v * 100))));
		y += ROW_HEIGHT;
		addDrawableChild(new SliderComponent(x, y, WIDTH, 20, -2.0, 4.0, () -> info.verticalOffset,
				v -> info.verticalOffset = (float) v, 0.05, v -> Text.translatable("francisekclient.format.literal", String.format("Vertical Offset: %.2f", v))));
		y += ROW_HEIGHT;

		return y;
	}

	private int buildFlightSettings(int x, int y) {
		ModConfig.FlightSettings flight = configManager.config().flight;

		addDrawableChild(new SliderComponent(x, y, WIDTH, 20, 0.1, 10.0, () -> flight.speed,
				v -> flight.speed = v, 0.1, v -> Text.translatable("francisekclient.format.literal", String.format("Speed: %.1fx", v))));
		y += ROW_HEIGHT;
		addDrawableChild(ToggleComponent.create(x, y, WIDTH, Text.translatable("francisekclient.format.literal", "Hover"), () -> flight.hover, v -> flight.hover = v));
		y += ROW_HEIGHT;
		addDrawableChild(ToggleComponent.create(x, y, WIDTH, Text.translatable("francisekclient.format.literal", "Status HUD"), () -> flight.statusHud, v -> flight.statusHud = v));
		y += ROW_HEIGHT;

		return y;
	}

	private int buildReachSettings(int x, int y, ReachAdjustment reach) {
		ModConfig.ReachSettings settings = configManager.config().reach;

		addDrawableChild(new SliderComponent(x, y, WIDTH, 20, settings.minReach, settings.maxReach, () -> settings.blockReach,
				v -> settings.blockReach = v, settings.increment, v -> Text.translatable("francisekclient.format.literal", String.format("Block Reach: %.1f", v))));
		y += ROW_HEIGHT;
		addDrawableChild(new SliderComponent(x, y, WIDTH, 20, settings.minReach, settings.maxReach, () -> settings.entityReach,
				v -> settings.entityReach = v, settings.increment, v -> Text.translatable("francisekclient.format.literal", String.format("Entity Reach: %.1f", v))));
		y += ROW_HEIGHT;

		addDrawableChild(ButtonWidget.builder(Text.translatable("francisekclient.format.literal", "Reset to Vanilla Defaults"), button -> {
					reach.resetConfigToDefaults();
					clearAndInit();
				})
				.dimensions(x, y, WIDTH, 20)
				.build());
		y += ROW_HEIGHT;

		return y;
	}

	private int addColorPicker(int x, int y, String label, java.util.function.IntSupplier getter, java.util.function.Consumer<Integer> setter) {
		ColorPickerComponent picker = new ColorPickerComponent(x, y, WIDTH, 20, Text.translatable("francisekclient.format.literal", label), getter, setter);
		colorPickers.add(picker);
		for (SliderComponent slider : picker.sliders()) {
			addDrawableChild(slider);
		}
		return y + picker.totalHeight(20) + 6;
	}

	private static Text renderModeLabel(ModConfig.RenderMode mode) {
		return Text.translatable("francisekclient.format.literal", "Render Mode: " + switch (mode) {
			case BOUNDING_BOX -> "Bounding Box";
			case OUTLINE -> "Outline";
			case GLOW -> "Glow";
		});
	}

	private static ModConfig.RenderMode nextRenderMode(ModConfig.RenderMode current) {
		ModConfig.RenderMode[] values = ModConfig.RenderMode.values();
		return values[(current.ordinal() + 1) % values.length];
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		renderBackground(context, mouseX, mouseY, delta);
		context.drawCenteredTextWithShadow(textRenderer, title, width / 2, height / 8 - 14, 0xFFFFFFFF);

		super.render(context, mouseX, mouseY, delta);

		for (ColorPickerComponent picker : colorPickers) {
			picker.render(context, textRenderer);
		}
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	@Override
	public void close() {
		configManager.save(false);
		if (client != null) {
			client.setScreen(parent);
		}
	}
}
