package me.francisek.client.util;

/**
 * Small numeric helpers shared across features, rendering code and the GUI.
 * Kept dependency-free so it can be unit-tested without touching Minecraft classes.
 */
public final class MathUtils {

	private MathUtils() {
	}

	public static double clamp(double value, double min, double max) {
		if (value < min) {
			return min;
		}
		if (value > max) {
			return max;
		}
		return value;
	}

	public static float clamp(float value, float min, float max) {
		if (value < min) {
			return min;
		}
		if (value > max) {
			return max;
		}
		return value;
	}

	public static int clamp(int value, int min, int max) {
		if (value < min) {
			return min;
		}
		if (value > max) {
			return max;
		}
		return value;
	}

	public static double lerp(double delta, double start, double end) {
		return start + (end - start) * delta;
	}

	public static float lerp(float delta, float start, float end) {
		return start + (end - start) * delta;
	}

	/**
	 * Rounds to a fixed number of decimal places for display purposes only.
	 * Never use the result for further calculation, only for UI text.
	 */
	public static double roundTo(double value, int decimals) {
		double factor = Math.pow(10, decimals);
		return Math.round(value * factor) / factor;
	}
}
