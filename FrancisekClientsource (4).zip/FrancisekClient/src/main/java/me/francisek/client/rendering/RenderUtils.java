package me.francisek.client.rendering;

import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;

/**
 * Shared camera/matrix-stack plumbing used by every world-space renderer in this mod
 * (currently {@link BoxRenderer}, {@link OutlineRenderer} and {@link WorldTextRenderer}).
 *
 * <p>Since Fabric API's extraction/draw split for world rendering (introduced for Minecraft
 * 1.21.10), the draw phase ({@code WorldRenderContext}) no longer exposes the {@link Camera}
 * directly - only the extraction phase ({@code WorldExtractionContext}) does. Every renderer in
 * this mod therefore works with positions that are already camera-relative by the time they
 * reach the draw phase: {@link #toCameraRelative} converts a world position during extraction,
 * and {@link #withRelativeSpace} translates the matrix stack by an already-relative offset
 * during drawing. No renderer in this mod touches {@link Camera} during the draw phase.
 */
public final class RenderUtils {

	private RenderUtils() {
	}

	/**
	 * Converts a world-space position into a camera-relative one. Call this during a feature's
	 * {@code extractWorld}, while the camera is still available, and store the result (or the
	 * raw floats) for the draw phase to use.
	 */
	public static Vec3d toCameraRelative(Vec3d worldPos, Vec3d cameraPos) {
		return worldPos.subtract(cameraPos);
	}

	/**
	 * Pushes the matrix stack and translates it by an already camera-relative offset. Callers
	 * MUST pair this with {@link MatrixStack#pop()} - see {@link #withRelativeSpace} for a
	 * version that guarantees the pop happens even if the render callback throws.
	 */
	public static void pushRelative(MatrixStack matrices, Vec3d relativePos) {
		matrices.push();
		matrices.translate(relativePos.x, relativePos.y, relativePos.z);
	}

	/**
	 * Runs {@code action} with the matrix stack translated to an already camera-relative
	 * offset, guaranteeing the push is popped afterwards even on exception. Prefer this over
	 * manual {@link #pushRelative} + pop pairs wherever practical.
	 */
	public static void withRelativeSpace(MatrixStack matrices, Vec3d relativePos, Runnable action) {
		pushRelative(matrices, relativePos);
		try {
			action.run();
		} finally {
			matrices.pop();
		}
	}
}
