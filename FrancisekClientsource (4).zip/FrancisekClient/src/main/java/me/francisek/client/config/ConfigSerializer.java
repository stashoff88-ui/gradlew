package me.francisek.client.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/**
 * Builds the single {@link Gson} instance used to read and write {@link ModConfig}.
 * Kept in its own class so the serialization format (pretty-printing, leniency) is
 * defined in exactly one place.
 */
public final class ConfigSerializer {

	private static final Gson GSON = new GsonBuilder()
			.setPrettyPrinting()
			.disableHtmlEscaping()
			.create();

	private ConfigSerializer() {
	}

	public static Gson gson() {
		return GSON;
	}
}
