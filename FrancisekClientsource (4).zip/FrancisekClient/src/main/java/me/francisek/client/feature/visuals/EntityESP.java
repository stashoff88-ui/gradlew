package me.francisek.client.feature.visuals;

import java.util.ArrayList;
import java.util.List;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldExtractionContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

import me.francisek.client.config.ConfigManager;
import me.francisek.client.config.ModConfig;
import me.francisek.client.feature.Feature;
import me.francisek.client.rendering.BoxRenderer;
import me.francisek.client.rendering.OutlineRenderer;
import me.francisek.client.util.ClientUtils;
import me.francisek.client.util.EntityUtils;

/**
 * Renders bounding boxes, outlines or a soft "glow" fill on nearby entities, categorised and
 * colored independently per {@link EntityUtils.Category}. Intended purely for local,
 * single-player visibility of loaded entities - it reads only the client's already-loaded
 * entity list and draws nothing that is not already present in the client world.
 *
 * <p>Split across Fabric API's world-render extraction/draw phases (see {@link Feature}):
 * {@link #extractWorld} does all the entity iteration, classification, distance culling and
 * camera-relative math while the camera and world are still available, and stores the result
 * as an immutable snapshot; {@link #renderWorld} just replays that snapshot into the vertex
 * buffers a moment later. Neither phase allocates per-entity beyond the one snapshot list.
 */
public class EntityESP extends Feature {

	private final ConfigManager configManager;
	private volatile List<EspEntry> snapshot = List.of();

	public EntityESP(ConfigManager configManager) {
		super("entity_esp", "francisekclient.feature.entity_esp.name", "francisekclient.feature.entity_esp.description", false);
		this.configManager = configManager;
	}

	private record EspEntry(float minX, float minY, float minZ, float maxX, float maxY, float maxZ,
			int color, ModConfig.RenderMode mode, float lineWidth) {
	}

	@Override
	public void extractWorld(WorldExtractionContext context) {
		ModConfig.EspSettings settings = configManager.config().esp;
		PlayerEntity self = ClientUtils.player();
		Camera camera = context.camera();
		Vec3d cameraPos = camera.getCameraPos();
		float tickDelta = context.tickCounter().getTickProgress(true);
		double maxDistanceSq = settings.maxDistance * settings.maxDistance;

		List<EspEntry> entries = new ArrayList<>();

		for (Entity entity : context.world().getEntities()) {
			if (!(entity instanceof LivingEntity living) || entity == self || !entity.isAlive()) {
				continue;
			}
			if (self.squaredDistanceTo(entity) > maxDistanceSq) {
				continue;
			}

			EntityUtils.Category category = EntityUtils.classify(living);
			if (!isCategoryEnabled(settings, category)) {
				continue;
			}

			int color = colorFor(settings, category);
			Vec3d pos = EntityUtils.interpolatedPosition(entity, tickDelta).subtract(cameraPos);
			float halfWidth = entity.getWidth() / 2.0f;
			float height = entity.getHeight();

			entries.add(new EspEntry(
					(float) (pos.x - halfWidth), (float) pos.y, (float) (pos.z - halfWidth),
					(float) (pos.x + halfWidth), (float) (pos.y + height), (float) (pos.z + halfWidth),
					color, settings.renderMode, settings.lineWidth
			));
		}

		this.snapshot = entries;
	}

	@Override
	public void renderWorld(WorldRenderContext context) {
		var matrices = context.matrices();
		var consumers = context.consumers();
		if (matrices == null || consumers == null) {
			return;
		}

		for (EspEntry entry : snapshot) {
			// GLOW draws a translucent fill (via the through-walls debug quads layer) plus a
			// wireframe outline for definition; BOUNDING_BOX/OUTLINE draw wireframe only, with
			// OUTLINE using a thinner line to read as a silhouette rather than a solid box.
			if (entry.mode() == ModConfig.RenderMode.GLOW) {
				OutlineRenderer.drawFilledBox(matrices, consumers,
						entry.minX(), entry.minY(), entry.minZ(), entry.maxX(), entry.maxY(), entry.maxZ(),
						(entry.color() & 0x00FFFFFF) | 0x30000000);
			}

			float lineWidth = entry.mode() == ModConfig.RenderMode.OUTLINE ? entry.lineWidth() * 0.5f : entry.lineWidth();
			BoxRenderer.drawWireframe(matrices, consumers,
					entry.minX(), entry.minY(), entry.minZ(), entry.maxX(), entry.maxY(), entry.maxZ(),
					entry.color(), lineWidth);
		}
	}

	private static boolean isCategoryEnabled(ModConfig.EspSettings settings, EntityUtils.Category category) {
		return switch (category) {
			case PLAYER -> settings.players;
			case HOSTILE -> settings.hostile;
			case PASSIVE -> settings.passive;
			case NEUTRAL -> settings.neutral;
			case VILLAGER -> settings.villagers;
			case OTHER -> settings.other;
		};
	}

	private static int colorFor(ModConfig.EspSettings settings, EntityUtils.Category category) {
		return switch (category) {
			case PLAYER -> settings.playerColor;
			case HOSTILE -> settings.hostileColor;
			case PASSIVE -> settings.passiveColor;
			case NEUTRAL -> settings.neutralColor;
			case VILLAGER -> settings.villagerColor;
			case OTHER -> settings.otherColor;
		};
	}
}
