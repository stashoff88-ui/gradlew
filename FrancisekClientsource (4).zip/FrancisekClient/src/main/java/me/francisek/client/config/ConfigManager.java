package me.francisek.client.config;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

import com.google.gson.JsonSyntaxException;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import me.francisek.client.util.TimeUtils;

/**
 * Owns reading and writing {@code config/francisekclient.json}.
 *
 * <p>Loading a malformed or missing file must never crash the client: every failure path
 * here falls back to {@link ConfigValidator#sanitize} defaults and logs a single warning
 * instead of propagating the exception. Saving is deliberately rate-limited so that rapid
 * GUI interactions (dragging a slider) do not translate into a disk write on every frame.
 */
public final class ConfigManager {

	private static final Logger LOGGER = LoggerFactory.getLogger("FrancisekClient/Config");
	private static final String FILE_NAME = "francisekclient.json";
	private static final long AUTOSAVE_MIN_INTERVAL_MS = 2000L;

	private final Path configPath;
	private ModConfig config;
	private long lastSaveMillis = 0L;
	private boolean saveScheduled = false;

	public ConfigManager() {
		this.configPath = FabricLoader.getInstance().getConfigDir().resolve(FILE_NAME);
	}

	public ModConfig config() {
		return config;
	}

	public void load() {
		ModConfig loaded = null;
		if (Files.exists(configPath)) {
			try {
				String json = Files.readString(configPath, StandardCharsets.UTF_8);
				loaded = ConfigSerializer.gson().fromJson(json, ModConfig.class);
			} catch (IOException e) {
				LOGGER.warn("Could not read {}, falling back to defaults: {}", configPath, e.toString());
			} catch (JsonSyntaxException e) {
				LOGGER.warn("Config file {} is corrupted, falling back to defaults: {}", configPath, e.toString());
			}
		}

		config = ConfigValidator.sanitize(loaded);

		// If anything was missing, malformed or clamped, immediately persist the repaired
		// version so the corrupt state on disk does not resurface after every restart.
		save(true);
	}

	/**
	 * Requests a save. By default this is rate-limited to {@link #AUTOSAVE_MIN_INTERVAL_MS}
	 * so that many small changes in a short window (e.g. dragging a slider) collapse into a
	 * single disk write once the interval has passed. Pass {@code immediate = true} for
	 * lifecycle events (shutdown, world disconnect) where the write must not be skipped.
	 */
	public void save(boolean immediate) {
		if (!immediate && !TimeUtils.hasElapsed(lastSaveMillis, AUTOSAVE_MIN_INTERVAL_MS)) {
			saveScheduled = true;
			return;
		}
		writeToDisk();
		lastSaveMillis = System.currentTimeMillis();
		saveScheduled = false;
	}

	/**
	 * Called periodically (e.g. once per second from a tick handler) to flush any save
	 * that was deferred by the rate limiter above.
	 */
	public void flushPendingSave() {
		if (saveScheduled && TimeUtils.hasElapsed(lastSaveMillis, AUTOSAVE_MIN_INTERVAL_MS)) {
			save(true);
		}
	}

	private void writeToDisk() {
		try {
			Path parent = configPath.getParent();
			if (parent != null) {
				Files.createDirectories(parent);
			}

			String json = ConfigSerializer.gson().toJson(config);

			// Write to a temp file first and atomically move it into place so a crash or
			// power loss mid-write can never leave a half-written, unparsable config file.
			Path tempFile = configPath.resolveSibling(FILE_NAME + ".tmp");
			Files.writeString(tempFile, json, StandardCharsets.UTF_8);
			Files.move(tempFile, configPath, StandardCopyOption.REPLACE_EXISTING);
		} catch (IOException e) {
			LOGGER.warn("Failed to save {}: {}", configPath, e.toString());
		}
	}
}
