package me.francisek.client.util;

/**
 * Lightweight monotonic timing helper for rate-limiting expensive work (config autosave,
 * console warnings, cache refreshes) without touching the game clock or allocating a
 * {@code java.time} object every call.
 */
public final class TimeUtils {

	private TimeUtils() {
	}

	/**
	 * Returns whether at least {@code intervalMillis} have passed since {@code lastMillis}.
	 * Callers are expected to update their own "last" timestamp with
	 * {@link System#currentTimeMillis()} when this returns true.
	 */
	public static boolean hasElapsed(long lastMillis, long intervalMillis) {
		return System.currentTimeMillis() - lastMillis >= intervalMillis;
	}
}
