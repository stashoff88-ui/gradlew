package me.francisek.client.gui;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.IntSupplier;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

import me.francisek.client.rendering.ColorUtils;

/**
 * A simple four-channel (alpha/red/green/blue) color editor: one {@link SliderComponent} per
 * channel plus a live preview swatch. This favours predictability and low implementation risk
 * over a full hue/saturation wheel, while still satisfying the spec's requirement that ESP and
 * text colors support alpha/transparency.
 *
 * <p>This class is not itself a {@code ClickableWidget} - it hands its four sliders to the
 * owning screen via {@link #sliders()} to be added normally with {@code addDrawableChild}, and
 * exposes {@link #renderSwatch} for the screen to call during its own render pass. This avoids
 * re-implementing the full widget/element/narration contract for a composite control.
 */
public final class ColorPickerComponent {

	private final IntSupplier colorGetter;
	private final List<SliderComponent> sliders;
	private final Text label;
	private final int labelX;
	private final int labelY;

	/**
	 * @param x     left edge of the label row and the swatch
	 * @param y     top of the label row; the four channel sliders are laid out in the
	 *              {@code rowHeight}-tall rows directly below it
	 */
	public ColorPickerComponent(int x, int y, int width, int rowHeight, Text label,
			IntSupplier colorGetter, Consumer<Integer> colorSetter) {
		this.colorGetter = colorGetter;
		this.label = label;
		this.labelX = x;
		this.labelY = y;

		int slidersY = y + rowHeight;
		SliderComponent alpha = channelSlider(x, slidersY, width, "A", ColorUtils::alpha, (argb, v) -> ColorUtils.withAlpha(argb, v), colorGetter, colorSetter);
		SliderComponent red = channelSlider(x, slidersY + rowHeight, width, "R", ColorUtils::red, (argb, v) -> combine(argb, v, ColorUtils.green(argb), ColorUtils.blue(argb), ColorUtils.alpha(argb)), colorGetter, colorSetter);
		SliderComponent green = channelSlider(x, slidersY + rowHeight * 2, width, "G", ColorUtils::green, (argb, v) -> combine(argb, ColorUtils.red(argb), v, ColorUtils.blue(argb), ColorUtils.alpha(argb)), colorGetter, colorSetter);
		SliderComponent blue = channelSlider(x, slidersY + rowHeight * 3, width, "B", ColorUtils::blue, (argb, v) -> combine(argb, ColorUtils.red(argb), ColorUtils.green(argb), v, ColorUtils.alpha(argb)), colorGetter, colorSetter);

		this.sliders = List.of(alpha, red, green, blue);
	}

	private interface ChannelGetter {
		int get(int argb);
	}

	private interface ChannelApplier {
		int apply(int argb, int newChannelValue);
	}

	private static int combine(int argb, int r, int g, int b, int a) {
		return ColorUtils.argb(a, r, g, b);
	}

	private SliderComponent channelSlider(int x, int y, int width, String prefix, ChannelGetter getter,
			ChannelApplier applier, IntSupplier colorGetter, Consumer<Integer> colorSetter) {
		return new SliderComponent(x, y, width, 20, 0, 255,
				() -> getter.get(colorGetter.getAsInt()),
				value -> colorSetter.accept(applier.apply(colorGetter.getAsInt(), (int) Math.round(value))),
				1.0,
				value -> Text.translatable("francisekclient.format.literal", prefix + ": " + (int) Math.round(value)));
	}

	public List<SliderComponent> sliders() {
		return sliders;
	}

	/** Total vertical space this picker occupies, including its label row and four sliders. */
	public int totalHeight(int rowHeight) {
		return rowHeight * 5;
	}

	/** Draws the label and a small preview swatch of the current color for this picker's row. */
	public void render(DrawContext context, TextRenderer textRenderer) {
		context.drawTextWithShadow(textRenderer, label, labelX, labelY + 6, 0xFFFFFFFF);

		int swatchSize = 14;
		int swatchX = labelX + textRenderer.getWidth(label) + 8;
		int argb = colorGetter.getAsInt();
		context.fill(swatchX, labelY, swatchX + swatchSize, labelY + swatchSize, 0xFF000000 | argb);

		// DrawContext.drawBorder(int,int,int,int,int) does not resolve against this project's
		// mapped Minecraft jar, so the 1px border is drawn manually as four thin fills instead -
		// DrawContext.fill(...) is used successfully everywhere else in this class already.
		int borderColor = 0xFFFFFFFF;
		context.fill(swatchX, labelY, swatchX + swatchSize, labelY + 1, borderColor);
		context.fill(swatchX, labelY + swatchSize - 1, swatchX + swatchSize, labelY + swatchSize, borderColor);
		context.fill(swatchX, labelY, swatchX + 1, labelY + swatchSize, borderColor);
		context.fill(swatchX + swatchSize - 1, labelY, swatchX + swatchSize, labelY + swatchSize, borderColor);
	}
}
