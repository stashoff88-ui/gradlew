package me.francisek.client.gui;

import java.util.List;

import net.minecraft.text.Text;

import me.francisek.client.feature.Feature;
import me.francisek.client.feature.movement.Flight;
import me.francisek.client.feature.movement.ReachAdjustment;
import me.francisek.client.feature.visuals.EntityESP;
import me.francisek.client.feature.visuals.EntityInfoOverlay;

/**
 * Describes one tab of {@link ClickGuiScreen}: a display name and the set of feature classes
 * shown under it, matching the category layout from the project spec (Visuals / Movement /
 * Player). "Player" is intentionally empty today - it exists as the documented landing spot
 * for future player-focused features without needing to touch the GUI layout again.
 */
public enum CategoryPanel {

	VISUALS("francisekclient.gui.category.visuals", List.of(EntityESP.class, EntityInfoOverlay.class)),
	MOVEMENT("francisekclient.gui.category.movement", List.of(Flight.class, ReachAdjustment.class)),
	PLAYER("francisekclient.gui.category.player", List.of());

	private final String translationKey;
	private final List<Class<? extends Feature>> featureTypes;

	CategoryPanel(String translationKey, List<Class<? extends Feature>> featureTypes) {
		this.translationKey = translationKey;
		this.featureTypes = featureTypes;
	}

	public Text displayName() {
		return Text.translatable(translationKey);
	}

	public List<Class<? extends Feature>> featureTypes() {
		return featureTypes;
	}

	public boolean contains(Feature feature) {
		for (Class<? extends Feature> type : featureTypes) {
			if (type.isInstance(feature)) {
				return true;
			}
		}
		return false;
	}
}
