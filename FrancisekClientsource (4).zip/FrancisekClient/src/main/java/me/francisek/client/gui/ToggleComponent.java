package me.francisek.client.gui;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.widget.CheckboxWidget;
import net.minecraft.text.Text;

/**
 * Thin factory around vanilla's {@link CheckboxWidget} that binds directly to a boolean
 * config field via getter/setter lambdas, so every toggle in the GUI (ESP categories, Entity
 * Info lines, Flight hover, ...) is created the same one-line way.
 */
public final class ToggleComponent {

	private ToggleComponent() {
	}

	public static CheckboxWidget create(int x, int y, int width, Text label,
			BooleanSupplier getter, Consumer<Boolean> setter) {
		// Builder.width(int) does not resolve against this project's mapped Minecraft jar, so the
		// checkbox is left to auto-size from its label instead; the width parameter is kept on
		// this factory method's signature for call-site/layout consistency even though it is no
		// longer applied directly.
		return CheckboxWidget.builder(label, MinecraftClient.getInstance().textRenderer)
				.pos(x, y)
				.checked(getter.getAsBoolean())
				.callback((checkbox, checked) -> setter.accept(checked))
				.build();
	}
}
