package me.francisek.client.rendering;

import me.francisek.client.util.MathUtils;

/**
 * Packed-ARGB color helpers. Every color setting in {@code ModConfig} and every color the
 * GUI's color picker produces is a single {@code int} in {@code 0xAARRGGBB} form, so the
 * rest of the rendering code never has to juggle four separate float/int channels.
 */
public final class ColorUtils {

	private ColorUtils() {
	}

	public static int argb(int alpha, int red, int green, int blue) {
		return (clampChannel(alpha) << 24)
				| (clampChannel(red) << 16)
				| (clampChannel(green) << 8)
				| clampChannel(blue);
	}

	public static int alpha(int argb) {
		return (argb >>> 24) & 0xFF;
	}

	public static int red(int argb) {
		return (argb >>> 16) & 0xFF;
	}

	public static int green(int argb) {
		return (argb >>> 8) & 0xFF;
	}

	public static int blue(int argb) {
		return argb & 0xFF;
	}

	/** Returns a copy of {@code argb} with its alpha channel replaced (0-255). */
	public static int withAlpha(int argb, int newAlpha) {
		return (clampChannel(newAlpha) << 24) | (argb & 0x00FFFFFF);
	}

	/** Returns a copy of {@code argb} with its alpha channel scaled by {@code factor} (0-1). */
	public static int scaleAlpha(int argb, float factor) {
		int newAlpha = Math.round(alpha(argb) * MathUtils.clamp(factor, 0f, 1f));
		return withAlpha(argb, newAlpha);
	}

	public static float redFloat(int argb) {
		return red(argb) / 255.0f;
	}

	public static float greenFloat(int argb) {
		return green(argb) / 255.0f;
	}

	public static float blueFloat(int argb) {
		return blue(argb) / 255.0f;
	}

	public static float alphaFloat(int argb) {
		return alpha(argb) / 255.0f;
	}

	private static int clampChannel(int value) {
		return MathUtils.clamp(value, 0, 255);
	}
}
