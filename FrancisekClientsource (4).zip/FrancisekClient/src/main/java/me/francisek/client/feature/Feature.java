package me.francisek.client.feature;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldExtractionContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

/**
 * Base type for every toggleable feature in the mod (Entity ESP, Entity Info, Flight, Reach,
 * and any future addition). Subclasses only implement the hooks they actually need; every
 * hook below already has a harmless no-op default.
 *
 * <p>A feature must not reach into another feature's internal state directly - if two
 * features need to coordinate, that coordination belongs in {@link FeatureManager} or in a
 * small shared utility, not in a direct feature-to-feature reference. This keeps every
 * feature independently toggleable and testable.
 *
 * <p>World rendering is split into two hooks, matching Fabric API's extraction/draw split
 * (introduced for Minecraft 1.21.10 to mirror Minecraft's own render rewrite):
 * {@link #extractWorld} runs first and is the only place with access to live world/camera
 * state ({@link WorldExtractionContext}); {@link #renderWorld} runs afterwards and only has
 * access to a matrix stack and vertex consumer provider ({@link WorldRenderContext}), so any
 * data a feature needs to draw with must be captured during extraction, not read again during
 * rendering.
 */
public abstract class Feature {

	private final String id;
	private final String nameTranslationKey;
	private final String descriptionTranslationKey;
	private boolean enabled;

	protected Feature(String id, String nameTranslationKey, String descriptionTranslationKey, boolean defaultEnabled) {
		this.id = id;
		this.nameTranslationKey = nameTranslationKey;
		this.descriptionTranslationKey = descriptionTranslationKey;
		this.enabled = defaultEnabled;
	}

	public final String id() {
		return id;
	}

	public final String nameTranslationKey() {
		return nameTranslationKey;
	}

	public final String descriptionTranslationKey() {
		return descriptionTranslationKey;
	}

	public final boolean isEnabled() {
		return enabled;
	}

	/**
	 * Enables or disables the feature, invoking {@link #onEnable()} / {@link #onDisable()}
	 * exactly once per genuine state change. Calling this with the current state again is a
	 * safe no-op, so GUI code does not need to guard against redundant toggles itself.
	 */
	public final void setEnabled(boolean value) {
		if (value == enabled) {
			return;
		}
		enabled = value;
		if (enabled) {
			onEnable();
		} else {
			onDisable();
		}
	}

	public final void toggle() {
		setEnabled(!enabled);
	}

	/** Called once, the moment this feature transitions from disabled to enabled. */
	protected void onEnable() {
	}

	/**
	 * Called once, the moment this feature transitions from enabled to disabled. Must undo
	 * anything {@link #onEnable()} or {@link #tick()} changed outside of this feature's own
	 * fields (movement flags, attribute overrides, etc).
	 */
	protected void onDisable() {
	}

	/** Runs once per client tick while the feature is enabled and a world is loaded. */
	public void tick() {
	}

	/**
	 * Runs once per rendered frame, before {@link #renderWorld}, while the feature is enabled
	 * and a world is loaded. This is the only hook with access to the live camera, world and
	 * tick counter - capture whatever {@link #renderWorld} will need into a plain field here.
	 */
	public void extractWorld(WorldExtractionContext context) {
	}

	/**
	 * Runs once per rendered frame, after {@link #extractWorld}, while the feature is enabled
	 * and a world is loaded. Only a matrix stack and vertex consumer provider are available
	 * here - draw using whatever was captured in {@link #extractWorld}, not live world state.
	 */
	public void renderWorld(WorldRenderContext context) {
	}

	/** Runs once per rendered frame while the feature is enabled, regardless of world state. */
	public void renderHud(DrawContext context, RenderTickCounter tickCounter) {
	}
}
