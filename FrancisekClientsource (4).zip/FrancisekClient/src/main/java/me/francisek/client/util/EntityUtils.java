package me.francisek.client.util;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.Angerable;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

/**
 * Entity classification and geometry helpers shared by the ESP and Entity Info features.
 *
 * <p>Vanilla Minecraft has no single "faction" API, so the Hostile / Passive / Neutral split
 * used by this mod is a deliberate, documented heuristic rather than an authoritative engine
 * concept:
 * <ul>
 *   <li>{@link Monster} is the marker interface vanilla itself uses for hostile mob spawning
 *       rules, so it is used here for the "Hostile" category.</li>
 *   <li>{@link Angerable} is implemented by mobs with vanilla's anger/neutral mechanic
 *       (wolves, bees, piglins, zombified piglins, ...), so it drives the "Neutral" category.</li>
 *   <li>{@link AnimalEntity} covers ordinary breedable/passive animals.</li>
 *   <li>Anything living that does not match any of the above (fish, bats, allays, armor
 *       stands with AI-less bodies, etc) falls into "Other".</li>
 * </ul>
 */
public final class EntityUtils {

	private EntityUtils() {
	}

	public enum Category {
		PLAYER,
		HOSTILE,
		PASSIVE,
		NEUTRAL,
		VILLAGER,
		OTHER
	}

	/**
	 * Classifies a living entity into one of the ESP categories. The check order matters:
	 * villagers are pulled out before the generic passive/animal check, and players are
	 * always resolved first since {@link PlayerEntity} does not overlap the other branches.
	 */
	public static Category classify(LivingEntity entity) {
		if (entity instanceof PlayerEntity) {
			return Category.PLAYER;
		}
		if (entity instanceof VillagerEntity) {
			return Category.VILLAGER;
		}
		if (entity instanceof Monster) {
			return Category.HOSTILE;
		}
		if (entity instanceof Angerable) {
			return Category.NEUTRAL;
		}
		if (entity instanceof AnimalEntity) {
			return Category.PASSIVE;
		}
		return Category.OTHER;
	}

	/**
	 * Interpolated (render-frame-correct) position of the entity for the given partial tick,
	 * matching what the vanilla renderer draws this frame. Always prefer this over
	 * {@link Entity#getPos()} for rendering to avoid visible jitter between ticks.
	 */
	public static Vec3d interpolatedPosition(Entity entity, float tickDelta) {
		return entity.getLerpedPos(tickDelta);
	}
}
