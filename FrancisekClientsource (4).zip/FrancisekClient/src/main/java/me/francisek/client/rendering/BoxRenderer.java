package me.francisek.client.rendering;

import org.joml.Matrix4f;

import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;

/**
 * Draws axis-aligned wireframe boxes in world space, using the same
 * {@code minecraft:rendertype_lines} layer vanilla itself uses for hitbox/debug rendering.
 * Used by {@link me.francisek.client.feature.visuals.EntityESP} for its "Bounding Box" and
 * "Outline" render modes.
 *
 * <p>Coordinates passed in here must already be camera-relative (see {@link RenderUtils}) -
 * this class never has access to the camera itself, since Fabric API's world-render draw phase
 * (where this is called from) does not expose it.
 */
public final class BoxRenderer {

	private BoxRenderer() {
	}

	/**
	 * Draws the 12 edges of an axis-aligned box, given already camera-relative bounds.
	 *
	 * <p>{@code lineWidth} is accepted for API/GUI consistency (it is a configurable setting)
	 * but is not currently applied: {@code RenderLayer.getLines()} does not expose a width
	 * parameter the way {@code RenderLayer.getDebugLineStrip(double)} does, and switching to a
	 * line-strip layer would require re-ordering these 12 independent edges into one connected
	 * strip. Left as a documented limitation rather than risking an unverified API for it.
	 *
	 * <p><b>UNRESOLVED - see README "Round 3" notes.</b> The user's real {@code javac} output
	 * shows {@code RenderLayer.getLines()} as "cannot find symbol" against their actual mapped
	 * jar, even though this exact call is what vanilla's own hitbox/debug renderer has used for
	 * many versions. Every other fix in this pass (Text.literal, Text.empty, DrawContext.drawBorder,
	 * CheckboxWidget.Builder.width) was resolvable by switching to a confirmed-working alternative
	 * API; {@code RenderLayer.getLines()} has no such confirmed-working alternative available to
	 * this project (no network access to re-verify the yarn-1.21.11+build.4 mapping, and every
	 * remote doc fetch attempted earlier in this project proved unreliable for this exact class).
	 * The call below is left as the historically-correct name rather than replaced with another
	 * guess. If it still fails to compile, open {@code RenderLayer} in your IDE and use
	 * autocomplete on {@code RenderLayer.} to find the real static factory name for a colored
	 * line layer in your resolved mappings, then swap it in here.
	 */
	public static void drawWireframe(MatrixStack matrices, VertexConsumerProvider consumers,
			float minX, float minY, float minZ, float maxX, float maxY, float maxZ,
			int argbColor, float lineWidth) {
		VertexConsumer buffer = consumers.getBuffer(RenderLayer.getLines());
		Matrix4f matrix = matrices.peek().getPositionMatrix();

		// Bottom face
		edge(buffer, matrix, argbColor, minX, minY, minZ, maxX, minY, minZ);
		edge(buffer, matrix, argbColor, maxX, minY, minZ, maxX, minY, maxZ);
		edge(buffer, matrix, argbColor, maxX, minY, maxZ, minX, minY, maxZ);
		edge(buffer, matrix, argbColor, minX, minY, maxZ, minX, minY, minZ);

		// Top face
		edge(buffer, matrix, argbColor, minX, maxY, minZ, maxX, maxY, minZ);
		edge(buffer, matrix, argbColor, maxX, maxY, minZ, maxX, maxY, maxZ);
		edge(buffer, matrix, argbColor, maxX, maxY, maxZ, minX, maxY, maxZ);
		edge(buffer, matrix, argbColor, minX, maxY, maxZ, minX, maxY, minZ);

		// Vertical edges
		edge(buffer, matrix, argbColor, minX, minY, minZ, minX, maxY, minZ);
		edge(buffer, matrix, argbColor, maxX, minY, minZ, maxX, maxY, minZ);
		edge(buffer, matrix, argbColor, maxX, minY, maxZ, maxX, maxY, maxZ);
		edge(buffer, matrix, argbColor, minX, minY, maxZ, minX, maxY, maxZ);
	}

	private static void edge(VertexConsumer buffer, Matrix4f matrix, int argb,
			float x1, float y1, float z1, float x2, float y2, float z2) {
		float nx = x2 - x1;
		float ny = y2 - y1;
		float nz = z2 - z1;
		float length = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
		if (length > 1.0e-4f) {
			nx /= length;
			ny /= length;
			nz /= length;
		}

		// Yarn 1.21.11 keeps the classic vertex()/color()/normal() method names (unlike
		// Mojang's own mappings, which renamed these to addVertex()/setColor()/setNormal()).
		// The underlying buffer now finalizes each vertex automatically - there is no
		// next()/endVertex() call to make, confirmed against the yarn-1.21.11 VertexConsumer
		// method list, which no longer declares one.
		buffer.vertex(matrix, x1, y1, z1)
				.color(argb)
				.normal(nx, ny, nz);
		buffer.vertex(matrix, x2, y2, z2)
				.color(argb)
				.normal(nx, ny, nz);
	}
}
