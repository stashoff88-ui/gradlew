package me.francisek.client.rendering;

import java.util.List;

import org.joml.Matrix4f;
import org.joml.Quaternionf;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

/**
 * Draws camera-facing ("billboarded") world-space text, the same technique vanilla uses for
 * entity nameplates. Used exclusively by {@link me.francisek.client.feature.visuals.EntityInfoOverlay}
 * so every info line in the mod goes through one rendering path instead of each feature
 * re-deriving the billboard math itself (project spec section 15: "reuse the shared
 * rendering system").
 *
 * <p>{@code relativePos} and {@code cameraRotation} must already be captured during a
 * feature's extraction phase (world position minus camera position, and
 * {@code Camera#getRotation()}) - the draw phase this is called from has no access to the
 * camera itself under Fabric API's extraction/draw split.
 */
public final class WorldTextRenderer {

	/** Matches vanilla's own nameplate scale-to-world conversion factor. */
	private static final float BASE_SCALE = 0.025f;

	private WorldTextRenderer() {
	}

	/**
	 * Draws a single line of {@code text} centered horizontally above {@code relativePos}
	 * (camera-relative), facing the camera, at {@code textScale} (1.0 = vanilla nameplate size).
	 */
	public static void drawLine(MatrixStack matrices, VertexConsumerProvider consumers, Quaternionf cameraRotation,
			Vec3d relativePos, Text text, float textScale, boolean background, float backgroundOpacity, int light) {
		TextRenderer textRenderer = MinecraftClient.getInstance().textRenderer;
		float scale = BASE_SCALE * textScale;

		RenderUtils.withRelativeSpace(matrices, relativePos, () -> {
			matrices.multiply(cameraRotation);
			matrices.scale(-scale, -scale, scale);

			Matrix4f matrix = matrices.peek().getPositionMatrix();
			int width = textRenderer.getWidth(text);
			float x = -width / 2.0f;

			int backgroundColor = background
					? ColorUtils.argb(Math.round(backgroundOpacity * 255), 0, 0, 0)
					: 0;

			textRenderer.draw(
					text,
					x,
					0,
					0xFFFFFFFF,
					false,
					matrix,
					consumers,
					background ? TextRenderer.TextLayerType.SEE_THROUGH : TextRenderer.TextLayerType.NORMAL,
					backgroundColor,
					light
			);
		});
	}

	/**
	 * Draws several stacked lines above {@code relativePos} (camera-relative), ordered
	 * top-to-bottom, each line separated by a fixed fraction of the text height so the whole
	 * block reads as one unit.
	 */
	public static void drawLines(MatrixStack matrices, VertexConsumerProvider consumers, Quaternionf cameraRotation,
			Vec3d relativePos, List<Text> lines, float textScale, boolean background,
			float backgroundOpacity, int light) {
		TextRenderer textRenderer = MinecraftClient.getInstance().textRenderer;
		int lineHeight = textRenderer.fontHeight + 2;

		for (int i = 0; i < lines.size(); i++) {
			// Highest line first, stacked upward, so the block grows away from the entity.
			float verticalOffset = (lines.size() - 1 - i) * lineHeight;
			Vec3d linePos = relativePos.add(0, verticalOffset * BASE_SCALE * textScale, 0);
			drawLine(matrices, consumers, cameraRotation, linePos, lines.get(i), textScale, background, backgroundOpacity, light);
		}
	}
}
