package me.francisek.client.rendering;

import org.joml.Matrix4f;

import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;

/**
 * Draws a soft, translucent filled box - used by {@link me.francisek.client.feature.visuals.EntityESP}'s
 * "Glow" render mode, layered underneath a {@link BoxRenderer} wireframe pass for definition.
 * Uses vanilla's own {@code rendertype_debug_quads} layer, the same one Minecraft's built-in
 * debug renderer (AI/pathfinding visualisation, spawn boxes) uses to draw diagnostic geometry
 * that stays visible through terrain - which is why this mode is the one used for ESP's
 * "see through walls" look instead of a manually toggled depth-test state: this project could
 * not confirm a still-existing global depth-test toggle on {@code RenderSystem} for 1.21.11
 * (it appears to have been folded into per-pipeline state as part of Minecraft's broader
 * rendering rewrite), so it deliberately relies on this already-through-walls vanilla layer
 * instead of an unverified API call.
 *
 * <p>Coordinates passed in here must already be camera-relative (see {@link RenderUtils}) -
 * this class never has access to the camera itself, since Fabric API's world-render draw phase
 * (where this is called from) does not expose it.
 */
public final class OutlineRenderer {

	private OutlineRenderer() {
	}

	// UNRESOLVED - see README "Round 3" notes and BoxRenderer's matching javadoc: the user's real
	// javac output shows RenderLayer.getDebugQuads() as "cannot find symbol" against their actual
	// mapped jar. No confirmed-working alternative name could be established without network
	// access, so this keeps the historically-correct name rather than guessing a third time. If
	// it still fails, autocomplete "RenderLayer." in your IDE for the real name of a translucent,
	// through-walls quad layer in your resolved mappings and swap it in here.
	public static void drawFilledBox(MatrixStack matrices, VertexConsumerProvider consumers,
			float minX, float minY, float minZ, float maxX, float maxY, float maxZ, int argbColor) {
		VertexConsumer buffer = consumers.getBuffer(RenderLayer.getDebugQuads());
		Matrix4f matrix = matrices.peek().getPositionMatrix();

		// -X / +X faces
		quad(buffer, matrix, argbColor, minX, minY, minZ, minX, maxY, minZ, minX, maxY, maxZ, minX, minY, maxZ, -1, 0, 0);
		quad(buffer, matrix, argbColor, maxX, minY, maxZ, maxX, maxY, maxZ, maxX, maxY, minZ, maxX, minY, minZ, 1, 0, 0);

		// -Y / +Y faces
		quad(buffer, matrix, argbColor, minX, minY, minZ, minX, minY, maxZ, maxX, minY, maxZ, maxX, minY, minZ, 0, -1, 0);
		quad(buffer, matrix, argbColor, minX, maxY, maxZ, minX, maxY, minZ, maxX, maxY, minZ, maxX, maxY, maxZ, 0, 1, 0);

		// -Z / +Z faces
		quad(buffer, matrix, argbColor, maxX, minY, minZ, maxX, maxY, minZ, minX, maxY, minZ, minX, minY, minZ, 0, 0, -1);
		quad(buffer, matrix, argbColor, minX, minY, maxZ, minX, maxY, maxZ, maxX, maxY, maxZ, maxX, minY, maxZ, 0, 0, 1);
	}

	// Yarn 1.21.11 keeps the classic vertex()/color()/normal() method names (unlike Mojang's
	// own mappings, which renamed these to addVertex()/setColor()/setNormal()); the buffer
	// finalizes each vertex automatically, so no next()/endVertex() call is needed.
	private static void quad(VertexConsumer buffer, Matrix4f matrix, int argb,
			float x1, float y1, float z1, float x2, float y2, float z2,
			float x3, float y3, float z3, float x4, float y4, float z4,
			float nx, float ny, float nz) {
		buffer.vertex(matrix, x1, y1, z1).color(argb).normal(nx, ny, nz);
		buffer.vertex(matrix, x2, y2, z2).color(argb).normal(nx, ny, nz);
		buffer.vertex(matrix, x3, y3, z3).color(argb).normal(nx, ny, nz);
		buffer.vertex(matrix, x4, y4, z4).color(argb).normal(nx, ny, nz);
	}
}
