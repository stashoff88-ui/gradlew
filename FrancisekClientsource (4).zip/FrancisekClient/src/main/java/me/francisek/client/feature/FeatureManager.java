package me.francisek.client.feature;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldExtractionContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

import me.francisek.client.util.ClientUtils;

/**
 * Central registry and dispatcher for every {@link Feature}. Features register themselves
 * once at startup; nothing else in the mod needs a static reference to an individual feature
 * instance beyond the handful of call sites (GUI, keybind handler) that look one up by type.
 */
public final class FeatureManager {

	private final Map<String, Feature> byId = new LinkedHashMap<>();
	private final List<Feature> features = new ArrayList<>();

	public void register(Feature feature) {
		features.add(feature);
		byId.put(feature.id(), feature);
	}

	public List<Feature> features() {
		return List.copyOf(features);
	}

	@SuppressWarnings("unchecked")
	public <T extends Feature> T get(Class<T> type) {
		for (Feature feature : features) {
			if (type.isInstance(feature)) {
				return (T) feature;
			}
		}
		throw new IllegalStateException("Feature not registered: " + type.getName());
	}

	/** Ticks every enabled feature, but only while a player and world actually exist. */
	public void tick() {
		if (!ClientUtils.inWorld()) {
			return;
		}
		for (Feature feature : features) {
			if (feature.isEnabled()) {
				feature.tick();
			}
		}
	}

	/** Extraction phase: runs first, while live world/camera state is still available. */
	public void extractWorld(WorldExtractionContext context) {
		if (!ClientUtils.inWorld()) {
			return;
		}
		for (Feature feature : features) {
			if (feature.isEnabled()) {
				feature.extractWorld(context);
			}
		}
	}

	/** Draw phase: runs after {@link #extractWorld}, using only data captured during it. */
	public void renderWorld(WorldRenderContext context) {
		if (!ClientUtils.inWorld()) {
			return;
		}
		for (Feature feature : features) {
			if (feature.isEnabled()) {
				feature.renderWorld(context);
			}
		}
	}

	public void renderHud(DrawContext context, RenderTickCounter tickCounter) {
		for (Feature feature : features) {
			if (feature.isEnabled()) {
				feature.renderHud(context, tickCounter);
			}
		}
	}

	/**
	 * Disables every feature that depends on an active world connection (currently Flight and
	 * Reach; ESP/Entity Info are read-only renderers and are safe to leave toggled). Called on
	 * disconnect / world leave so a feature can never carry altered player state into a
	 * different world, a respawn, or the main menu.
	 */
	public void disableWorldDependentFeatures() {
		for (Feature feature : features) {
			if (feature instanceof WorldDependent && feature.isEnabled()) {
				feature.setEnabled(false);
			}
		}
	}

	/** Marker for features that must never remain "enabled" across a world change. */
	public interface WorldDependent {
	}
}
