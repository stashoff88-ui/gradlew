package me.francisek.client.feature.movement;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;

import me.francisek.client.config.ConfigManager;
import me.francisek.client.config.ModConfig;
import me.francisek.client.feature.Feature;
import me.francisek.client.feature.FeatureManager;
import me.francisek.client.util.ClientUtils;

/**
 * Adjusts the local player's block and entity interaction range for single-player testing.
 *
 * <h2>How this works</h2>
 * Since Minecraft 1.20.5, reach is no longer a hardcoded constant: it is driven by the two
 * vanilla entity attributes {@link EntityAttributes#BLOCK_INTERACTION_RANGE} and
 * {@link EntityAttributes#ENTITY_INTERACTION_RANGE}, exactly like attack damage or movement
 * speed. This feature simply writes to those attributes' base value on the local player, using
 * the ordinary {@link EntityAttributeInstance} API every mod already uses for attributes - no
 * mixin, packet manipulation, or interaction-handling override is needed or used, in line with
 * the project's "avoid mixins whenever Fabric API / vanilla already exposes a hook" rule.
 *
 * <p>Because this only ever changes an attribute value on the client's own player entity, and
 * both survival and creative players already have these attributes, this works identically to
 * how a mod like a strength or reach-granting enchantment would - it is a legitimate, local
 * gameplay value change, not an interaction/raycast bypass.
 */
public class ReachAdjustment extends Feature implements FeatureManager.WorldDependent {

	private final ConfigManager configManager;

	public ReachAdjustment(ConfigManager configManager) {
		super("reach", "francisekclient.feature.reach.name", "francisekclient.feature.reach.description", false);
		this.configManager = configManager;
	}

	@Override
	protected void onEnable() {
		apply();
	}

	@Override
	protected void onDisable() {
		restoreDefaults();
	}

	@Override
	public void tick() {
		// Re-applied every tick (cheap attribute writes) so the override survives a player
		// respawn, which replaces the ClientPlayerEntity instance and its attribute container.
		apply();
	}

	private void apply() {
		ClientPlayerEntity player = ClientUtils.player();
		if (player == null) {
			return;
		}
		ModConfig.ReachSettings settings = configManager.config().reach;

		EntityAttributeInstance blockRange = player.getAttributeInstance(EntityAttributes.BLOCK_INTERACTION_RANGE);
		if (blockRange != null) {
			blockRange.setBaseValue(settings.blockReach);
		}

		EntityAttributeInstance entityRange = player.getAttributeInstance(EntityAttributes.ENTITY_INTERACTION_RANGE);
		if (entityRange != null) {
			entityRange.setBaseValue(settings.entityReach);
		}
	}

	private void restoreDefaults() {
		ClientPlayerEntity player = ClientUtils.player();
		if (player == null) {
			return;
		}

		EntityAttributeInstance blockRange = player.getAttributeInstance(EntityAttributes.BLOCK_INTERACTION_RANGE);
		if (blockRange != null) {
			blockRange.setBaseValue(ModConfig.ReachSettings.DEFAULT_BLOCK_REACH);
		}

		EntityAttributeInstance entityRange = player.getAttributeInstance(EntityAttributes.ENTITY_INTERACTION_RANGE);
		if (entityRange != null) {
			entityRange.setBaseValue(ModConfig.ReachSettings.DEFAULT_ENTITY_REACH);
		}
	}

	/** Resets the reach values in the config back to vanilla defaults, used by the GUI's Reset control. */
	public void resetConfigToDefaults() {
		ModConfig.ReachSettings settings = configManager.config().reach;
		settings.blockReach = ModConfig.ReachSettings.DEFAULT_BLOCK_REACH;
		settings.entityReach = ModConfig.ReachSettings.DEFAULT_ENTITY_REACH;
		if (isEnabled()) {
			apply();
		}
		configManager.save(false);
	}
}
