package me.francisek.client.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;

/**
 * Centralised null-safety helpers for the pieces of {@link MinecraftClient} state that
 * every feature needs on a near-constant basis. Nothing in this project should read
 * {@code MinecraftClient.getInstance().player} or {@code .world} directly - the client
 * player and world are only non-null while genuinely in a loaded world, and both fields
 * can flip back to null between any two ticks (disconnects, dimension changes, crashes
 * in other mods, resource reloads, etc). Routing every read through here means that
 * lifecycle bug fixes only need to happen in one place.
 */
public final class ClientUtils {

	private ClientUtils() {
	}

	public static MinecraftClient client() {
		return MinecraftClient.getInstance();
	}

	public static ClientPlayerEntity player() {
		return client().player;
	}

	public static ClientWorld world() {
		return client().world;
	}

	/**
	 * @return true only when both a player and a world are present, i.e. it is safe
	 * to run per-tick or per-frame feature logic that touches either.
	 */
	public static boolean inWorld() {
		MinecraftClient mc = client();
		return mc.player != null && mc.world != null;
	}
}
