package me.francisek.client.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.CheckboxWidget;
import net.minecraft.text.Text;

import me.francisek.client.feature.Feature;

/**
 * One row in {@link ClickGuiScreen}'s module list: a checkbox that toggles the feature on/off,
 * and a small settings button that opens the feature's {@link SettingsScreen}. This class is a
 * thin grouping helper rather than a widget itself - it builds and returns the two real
 * widgets so the screen adds them normally via {@code addDrawableChild}.
 */
public final class ModuleButton {

	private final CheckboxWidget toggle;
	private final ButtonWidget settingsButton;

	public ModuleButton(int x, int y, int width, int height, Feature feature, ClickGuiScreen owner) {
		// Builder.width(int) does not resolve against this project's mapped Minecraft jar (see
		// ToggleComponent for the same fix), so the checkbox auto-sizes from its label instead of
		// being stretched to fill the row.
		this.toggle = CheckboxWidget.builder(Text.translatable(feature.nameTranslationKey()),
						MinecraftClient.getInstance().textRenderer)
				.pos(x, y)
				.checked(feature.isEnabled())
				.callback((checkbox, checked) -> feature.setEnabled(checked))
				.build();

		this.settingsButton = ButtonWidget.builder(Text.translatable("francisekclient.format.literal", "..."),
						button -> owner.openSettings(feature))
				.dimensions(x + width - height, y, height, height)
				.build();
	}

	public CheckboxWidget toggle() {
		return toggle;
	}

	public ButtonWidget settingsButton() {
		return settingsButton;
	}
}
