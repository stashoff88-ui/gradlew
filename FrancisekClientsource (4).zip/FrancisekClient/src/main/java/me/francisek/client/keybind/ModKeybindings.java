package me.francisek.client.keybind;

import org.lwjgl.glfw.GLFW;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;

import me.francisek.client.FrancisekClient;

/**
 * Central registration point for every {@link KeyBinding} this mod defines. No feature or
 * screen should ever poll raw keyboard/GLFW state directly - going through a registered
 * {@link KeyBinding} means Minecraft's own key-conflict handling, rebinding UI compatibility,
 * and options.txt persistence all keep working for free.
 *
 * <p>Both bindings below are rebindable in-game through vanilla's Controls screen as well as
 * this mod's own Click GUI keybind selector; changing one updates the exact same underlying
 * {@link KeyBinding}, so the two stay in sync automatically.
 *
 * <p>As of the 1.21.2+ key binding refactor, categories are no longer plain translation-key
 * strings - they are {@link KeyBinding.Category} instances created from an {@link Identifier}
 * via {@link KeyBinding.Category#create(Identifier)}. The category's display name is looked up
 * from the translation key {@code key.category.<namespace>.<path>}, which is provided in
 * {@code assets/francisekclient/lang/en_us.json}.
 */
public final class ModKeybindings {

	private static final KeyBinding.Category CATEGORY = KeyBinding.Category.create(Identifier.of(FrancisekClient.MOD_ID, "main"));

	public static final KeyBinding OPEN_GUI = new KeyBinding(
			"key.francisekclient.open_gui",
			InputUtil.Type.KEYSYM,
			GLFW.GLFW_KEY_RIGHT_SHIFT,
			CATEGORY
	);

	public static final KeyBinding TOGGLE_FLIGHT = new KeyBinding(
			"key.francisekclient.toggle_flight",
			InputUtil.Type.KEYSYM,
			GLFW.GLFW_KEY_G,
			CATEGORY
	);

	private ModKeybindings() {
	}

	public static void register() {
		KeyBindingHelper.registerKeyBinding(OPEN_GUI);
		KeyBindingHelper.registerKeyBinding(TOGGLE_FLIGHT);
	}
}
