package me.francisek.client.client;

import net.minecraft.client.MinecraftClient;

import me.francisek.client.config.ConfigManager;
import me.francisek.client.feature.FeatureManager;
import me.francisek.client.feature.movement.Flight;
import me.francisek.client.gui.ClickGuiScreen;
import me.francisek.client.keybind.ModKeybindings;

/**
 * Handles the mod's per-client-tick work: consuming keybind presses and driving every
 * feature's {@link me.francisek.client.feature.Feature#tick()}. Kept separate from
 * {@link FrancisekClient} itself so the entrypoint class stays a thin wiring layer.
 */
public final class ClientTickHandler {

	private final FeatureManager featureManager;
	private final ConfigManager configManager;

	public ClientTickHandler(FeatureManager featureManager, ConfigManager configManager) {
		this.featureManager = featureManager;
		this.configManager = configManager;
	}

	public void onEndTick(MinecraftClient client) {
		handleKeybinds(client);
		featureManager.tick();
		configManager.flushPendingSave();
	}

	private void handleKeybinds(MinecraftClient client) {
		while (ModKeybindings.OPEN_GUI.wasPressed()) {
			// Toggle, not just open: pressing the bound key again while the Click GUI is already
			// open closes it (matching how most client mods bind their menu key), instead of
			// requiring Escape or the "Done" button. Only ever touches our own screen - if some
			// other screen (inventory, chat, another mod's GUI) is open, this key does nothing,
			// so it never steals a keypress meant for something else.
			if (client.currentScreen instanceof ClickGuiScreen clickGui) {
				// Route through close() rather than client.setScreen(null) directly, so
				// ClickGuiScreen's own close() override (which saves the config immediately)
				// still runs - the same path Escape or a widget-driven close would take.
				clickGui.close();
			} else if (client.currentScreen == null) {
				client.setScreen(new ClickGuiScreen(featureManager, configManager));
			}
		}

		while (ModKeybindings.TOGGLE_FLIGHT.wasPressed()) {
			featureManager.get(Flight.class).toggle();
		}
	}
}
