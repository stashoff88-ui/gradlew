package me.francisek.client.config;

import me.francisek.client.util.MathUtils;

/**
 * Repairs a freshly deserialized {@link ModConfig}.
 *
 * <p>Gson silently leaves any missing JSON field at whatever the class's field initializer
 * set it to (null for objects, since Gson does not run constructors of nested objects that
 * are absent from the JSON) - so a config file that predates a newly added section, or one
 * that was hand-edited into an invalid state, must never be trusted as-is. This class fills
 * in missing sections with fresh defaults and clamps every numeric field into its valid
 * range, so a corrupted or outdated config file can never crash the mod or leave it in an
 * unreasonable state.
 */
public final class ConfigValidator {

	private ConfigValidator() {
	}

	public static ModConfig sanitize(ModConfig config) {
		ModConfig safe = config != null ? config : new ModConfig();

		if (safe.esp == null) {
			safe.esp = new ModConfig.EspSettings();
		}
		if (safe.entityInfo == null) {
			safe.entityInfo = new ModConfig.EntityInfoSettings();
		}
		if (safe.flight == null) {
			safe.flight = new ModConfig.FlightSettings();
		}
		if (safe.reach == null) {
			safe.reach = new ModConfig.ReachSettings();
		}
		if (safe.gui == null) {
			safe.gui = new ModConfig.GuiSettings();
		}
		if (safe.esp.renderMode == null) {
			safe.esp.renderMode = ModConfig.RenderMode.BOUNDING_BOX;
		}

		sanitizeEsp(safe.esp);
		sanitizeEntityInfo(safe.entityInfo);
		sanitizeFlight(safe.flight);
		sanitizeReach(safe.reach);
		sanitizeGui(safe.gui);

		return safe;
	}

	private static void sanitizeEsp(ModConfig.EspSettings esp) {
		esp.maxDistance = MathUtils.clamp(esp.maxDistance, 4.0, 512.0);
		esp.lineWidth = MathUtils.clamp(esp.lineWidth, 0.5f, 8.0f);
		esp.playerColor = withOpaqueFallback(esp.playerColor);
		esp.hostileColor = withOpaqueFallback(esp.hostileColor);
		esp.passiveColor = withOpaqueFallback(esp.passiveColor);
		esp.neutralColor = withOpaqueFallback(esp.neutralColor);
		esp.villagerColor = withOpaqueFallback(esp.villagerColor);
		esp.otherColor = withOpaqueFallback(esp.otherColor);
	}

	private static void sanitizeEntityInfo(ModConfig.EntityInfoSettings info) {
		info.maxDistance = MathUtils.clamp(info.maxDistance, 4.0, 256.0);
		info.textScale = MathUtils.clamp(info.textScale, 0.25f, 3.0f);
		info.backgroundOpacity = MathUtils.clamp(info.backgroundOpacity, 0.0f, 1.0f);
		info.verticalOffset = MathUtils.clamp(info.verticalOffset, -2.0f, 4.0f);
	}

	private static void sanitizeFlight(ModConfig.FlightSettings flight) {
		flight.speed = MathUtils.clamp(flight.speed, 0.1, 10.0);
	}

	private static void sanitizeReach(ModConfig.ReachSettings reach) {
		if (reach.minReach <= 0 || reach.minReach > reach.maxReach) {
			reach.minReach = ModConfig.ReachSettings.DEFAULT_ENTITY_REACH;
		}
		if (reach.maxReach <= reach.minReach) {
			reach.maxReach = Math.max(reach.minReach + 1.0, 10.0);
		}
		reach.maxReach = MathUtils.clamp(reach.maxReach, reach.minReach + 0.5, 32.0);
		reach.increment = MathUtils.clamp(reach.increment, 0.1, 5.0);
		reach.blockReach = MathUtils.clamp(reach.blockReach, reach.minReach, reach.maxReach);
		reach.entityReach = MathUtils.clamp(reach.entityReach, reach.minReach, reach.maxReach);
	}

	private static void sanitizeGui(ModConfig.GuiSettings gui) {
		gui.scale = MathUtils.clamp(gui.scale, 0.5f, 2.0f);
	}

	/**
	 * A color value of 0 (fully transparent black - the Java default for an {@code int}
	 * field that Gson leaves untouched) would render as invisible, which reads as a bug
	 * rather than a deliberate choice. Treat it as "not actually configured" and fall
	 * back to opaque white instead of silently rendering nothing.
	 */
	private static int withOpaqueFallback(int argb) {
		return argb == 0 ? 0xFFFFFFFF : argb;
	}
}
