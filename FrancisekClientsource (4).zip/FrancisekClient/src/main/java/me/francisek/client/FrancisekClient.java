package me.francisek.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.util.Identifier;

import me.francisek.client.client.ClientLifecycleHandler;
import me.francisek.client.client.ClientTickHandler;
import me.francisek.client.config.ConfigManager;
import me.francisek.client.feature.FeatureManager;
import me.francisek.client.feature.movement.Flight;
import me.francisek.client.feature.movement.ReachAdjustment;
import me.francisek.client.feature.visuals.EntityESP;
import me.francisek.client.feature.visuals.EntityInfoOverlay;
import me.francisek.client.keybind.ModKeybindings;

/**
 * Client entrypoint for Francisek Client.
 *
 * <p>This class only wires things together: it constructs the config manager and every
 * feature, registers keybindings, and hooks the mod into the handful of Fabric API events it
 * needs. All actual behaviour lives in the {@code feature}, {@code config}, {@code rendering}
 * and {@code gui} packages so this class stays readable as a single "what does this mod do"
 * overview.
 */
public class FrancisekClient implements ClientModInitializer {

	public static final String MOD_ID = "francisekclient";
	public static final Logger LOGGER = LoggerFactory.getLogger("FrancisekClient");

	private static ConfigManager configManager;
	private static FeatureManager featureManager;

	@Override
	public void onInitializeClient() {
		configManager = new ConfigManager();
		configManager.load();

		featureManager = new FeatureManager();
		featureManager.register(new EntityESP(configManager));
		featureManager.register(new EntityInfoOverlay(configManager));
		featureManager.register(new Flight(configManager));
		featureManager.register(new ReachAdjustment(configManager));

		ModKeybindings.register();

		ClientTickHandler tickHandler = new ClientTickHandler(featureManager, configManager);
		ClientTickEvents.END_CLIENT_TICK.register(tickHandler::onEndTick);

		// Extraction runs first (live camera/world access), drawing runs after (matrix stack +
		// vertex consumers only) - see Feature's class javadoc for why this is split in two.
		WorldRenderEvents.END_EXTRACTION.register(featureManager::extractWorld);
		WorldRenderEvents.AFTER_ENTITIES.register(featureManager::renderWorld);

		HudElementRegistry.addLast(
				Identifier.of(MOD_ID, "hud"),
				(context, tickCounter) -> featureManager.renderHud(context, tickCounter)
		);

		new ClientLifecycleHandler(featureManager, configManager).register();

		LOGGER.info("Francisek Client initialized (client-side only, Minecraft 1.21.11).");
	}

	public static ConfigManager configManager() {
		return configManager;
	}

	public static FeatureManager featureManager() {
		return featureManager;
	}
}
