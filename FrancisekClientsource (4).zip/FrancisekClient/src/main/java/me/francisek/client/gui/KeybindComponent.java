package me.francisek.client.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ScreenTexts;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;

/**
 * A rebindable key selector button, used for "Open GUI" and "Toggle Flight" in the Player /
 * settings screens. Clicking the button puts it into "listening" state (label changes to
 * "&gt; ... &lt;"); the next key press anywhere in the owning screen is captured by
 * {@link ClickGuiScreen#keyPressed} / {@link SettingsScreen#keyPressed} and applied here via
 * {@link #applyKey}, exactly like vanilla's own Controls screen key-binding buttons.
 */
public class KeybindComponent extends ButtonWidget {

	private final KeyBinding keyBinding;
	private boolean listening = false;

	public KeybindComponent(int x, int y, int width, int height, KeyBinding keyBinding) {
		// ScreenTexts.EMPTY replaces Text.empty(): the no-arg Text.empty() factory does not
		// resolve against this project's mapped Minecraft jar, but ScreenTexts.EMPTY is the same
		// vanilla-internal empty-text constant that ButtonWidget itself uses elsewhere, so it is
		// guaranteed to exist alongside the ButtonWidget class this extends.
		super(x, y, width, height, ScreenTexts.EMPTY, button -> {
		}, DEFAULT_NARRATION_SUPPLIER);
		this.keyBinding = keyBinding;
		refreshLabel();
	}

	@Override
	public void onPress() {
		listening = true;
		setMessage(Text.translatable("francisekclient.gui.listening"));
	}

	public boolean isListening() {
		return listening;
	}

	/**
	 * Binds the key from {@code input} and persists it, matching vanilla's Controls screen.
	 *
	 * <p><b>Best-effort / UNVERIFIED - see README "Round 4" notes.</b> {@code Screen.keyPressed}
	 * now takes a single {@code KeyInput} record instead of {@code (int keyCode, int scanCode,
	 * int modifiers)}, per your real {@code javac} output. This is a newer API this project has
	 * no prior ground truth for, so {@code input.key()} below is a best-effort guess based on
	 * Java record-accessor convention (matching the old parameter name {@code keyCode}), not a
	 * verified mapping. If this line fails to compile, open {@code KeyInput} in your IDE (go to
	 * declaration on the {@code input} parameter of {@link ClickGuiScreen#keyPressed}) and tell
	 * me its real accessor names so this can be corrected precisely instead of guessed again.
	 */
	public void applyKey(KeyInput input) {
		keyBinding.setBoundKey(InputUtil.Type.KEYSYM.createFromCode(input.key()));
		KeyBinding.updateKeysByCode();
		MinecraftClient.getInstance().options.write();
		listening = false;
		refreshLabel();
	}

	public void cancelListening() {
		listening = false;
		refreshLabel();
	}

	private void refreshLabel() {
		setMessage(keyBinding.getBoundKeyLocalizedText());
	}

	/**
	 * No-op override: {@code PressableWidget.drawIcon(DrawContext,int,int,float)} is abstract
	 * against this project's mapped Minecraft jar (per your real {@code javac} output), meaning
	 * {@code ButtonWidget} no longer supplies a default no-icon implementation the way it used
	 * to. This button is text-only (matches vanilla's own Controls screen key-binding buttons),
	 * so the override intentionally does nothing.
	 */
	@Override
	protected void drawIcon(DrawContext context, int x, int y, float alpha) {
	}
}
