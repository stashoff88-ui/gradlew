package me.francisek.client.gui;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;

import me.francisek.client.config.ConfigManager;
import me.francisek.client.feature.Feature;
import me.francisek.client.feature.FeatureManager;
import me.francisek.client.keybind.ModKeybindings;

/**
 * The mod's main in-game menu: category tabs across the top (Visuals / Movement / Player),
 * a toggle + settings row per feature in the selected category, and the two keybind selectors
 * required by the project spec (Open GUI, Toggle Flight) pinned at the bottom.
 *
 * <p>Opened with {@link ModKeybindings#OPEN_GUI} (configurable, default Right Shift). Closing
 * it does not pause single-player (this mod never sets {@link #shouldPause()} to true), since
 * it is meant to be adjusted while playing.
 */
public class ClickGuiScreen extends Screen {

	private static final int PANEL_WIDTH = 220;
	private static final int ROW_HEIGHT = 22;

	private final FeatureManager featureManager;
	private final ConfigManager configManager;

	private CategoryPanel selectedCategory = CategoryPanel.VISUALS;
	private final List<ModuleButton> moduleButtons = new ArrayList<>();
	private KeybindComponent openGuiKeybind;
	private KeybindComponent toggleFlightKeybind;

	public ClickGuiScreen(FeatureManager featureManager, ConfigManager configManager) {
		super(Text.translatable("francisekclient.gui.title"));
		this.featureManager = featureManager;
		this.configManager = configManager;
	}

	@Override
	protected void init() {
		int panelX = (width - PANEL_WIDTH) / 2;
		int top = height / 6;

		int tabWidth = PANEL_WIDTH / CategoryPanel.values().length;
		int tabIndex = 0;
		for (CategoryPanel category : CategoryPanel.values()) {
			int tabX = panelX + tabIndex * tabWidth;
			addDrawableChild(ButtonWidget.builder(category.displayName(), button -> selectCategory(category))
					.dimensions(tabX, top, tabWidth, 20)
					.build());
			tabIndex++;
		}

		int afterModulesY = buildModuleRows(panelX, top + 26);

		int keybindY = afterModulesY + 16;
		openGuiKeybind = new KeybindComponent(panelX, keybindY, PANEL_WIDTH / 2 - 2, 20, ModKeybindings.OPEN_GUI);
		toggleFlightKeybind = new KeybindComponent(panelX + PANEL_WIDTH / 2 + 2, keybindY, PANEL_WIDTH / 2 - 2, 20, ModKeybindings.TOGGLE_FLIGHT);
		addDrawableChild(openGuiKeybind);
		addDrawableChild(toggleFlightKeybind);
	}

	private void selectCategory(CategoryPanel category) {
		this.selectedCategory = category;
		clearAndInit();
	}

	private int buildModuleRows(int panelX, int startY) {
		moduleButtons.clear();
		int y = startY;
		for (Feature feature : featureManager.features()) {
			if (!selectedCategory.contains(feature)) {
				continue;
			}
			ModuleButton row = new ModuleButton(panelX, y, PANEL_WIDTH, 20, feature, this);
			addDrawableChild(row.toggle());
			addDrawableChild(row.settingsButton());
			moduleButtons.add(row);
			y += ROW_HEIGHT;
		}
		return y;
	}

	/** Called by {@link ModuleButton}'s settings button. */
	public void openSettings(Feature feature) {
		this.client.setScreen(new SettingsScreen(this, feature, configManager));
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		renderBackground(context, mouseX, mouseY, delta);

		int panelX = (width - PANEL_WIDTH) / 2;
		int top = height / 6;
		context.drawCenteredTextWithShadow(textRenderer, title, width / 2, top - 14, 0xFFFFFFFF);

		if (moduleButtons.isEmpty()) {
			context.drawCenteredTextWithShadow(textRenderer,
					Text.translatable("francisekclient.format.literal", "(no modules in this category yet)"),
					width / 2, top + 26 + 4, 0xAAAAAA);
		}

		super.render(context, mouseX, mouseY, delta);
	}

	// Screen.keyPressed now takes a single KeyInput instead of (int,int,int) - see
	// KeybindComponent.applyKey's javadoc for the full explanation and the one open question
	// about KeyInput's exact accessor names.
	@Override
	public boolean keyPressed(KeyInput input) {
		if (openGuiKeybind != null && openGuiKeybind.isListening()) {
			openGuiKeybind.applyKey(input);
			return true;
		}
		if (toggleFlightKeybind != null && toggleFlightKeybind.isListening()) {
			toggleFlightKeybind.applyKey(input);
			return true;
		}
		return super.keyPressed(input);
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	@Override
	public void close() {
		configManager.save(true);
		super.close();
	}
}
