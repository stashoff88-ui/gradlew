package me.francisek.client.config;

/**
 * Plain serializable data holder for every persisted setting in the mod.
 *
 * <p>This class intentionally contains no logic beyond simple nested groups: it is
 * serialized to / deserialized from JSON as-is by {@link ConfigSerializer}. Validation
 * and clamping live in {@link ConfigValidator}, and file I/O lives in {@link ConfigManager},
 * so that a corrupt or partially-missing file can never leave the mod in an inconsistent
 * in-memory state.
 */
public class ModConfig {

	public int configVersion = 1;

	public EspSettings esp = new EspSettings();
	public EntityInfoSettings entityInfo = new EntityInfoSettings();
	public FlightSettings flight = new FlightSettings();
	public ReachSettings reach = new ReachSettings();
	public GuiSettings gui = new GuiSettings();

	// Keybindings are intentionally NOT stored here. Every KeyBinding registered through
	// KeyBindingHelper is automatically persisted by vanilla's own GameOptions / options.txt
	// system, including changes made from this mod's Click GUI. Duplicating that in our own
	// config file would create two competing sources of truth for the same key.

	public enum RenderMode {
		BOUNDING_BOX,
		OUTLINE,
		GLOW
	}

	public static class EspSettings {
		public boolean enabled = false;
		public RenderMode renderMode = RenderMode.BOUNDING_BOX;

		public boolean players = true;
		public boolean hostile = true;
		public boolean passive = false;
		public boolean neutral = false;
		public boolean villagers = false;
		public boolean other = false;

		public double maxDistance = 64.0;
		public float lineWidth = 2.0f;

		// Colors are stored as packed ARGB ints (0xAARRGGBB) so they serialize as a
		// single JSON number and round-trip through the color picker without any
		// intermediate object allocation.
		public int playerColor = 0xFFFF5555;
		public int hostileColor = 0xFFFF3333;
		public int passiveColor = 0xFF55FF55;
		public int neutralColor = 0xFFFFAA33;
		public int villagerColor = 0xFF55AAFF;
		public int otherColor = 0xFFAAAAAA;
	}

	public static class EntityInfoSettings {
		public boolean enabled = false;
		public boolean showName = true;
		public boolean showHealth = true;
		public boolean showDistance = true;
		public double maxDistance = 32.0;
		public float textScale = 1.0f;
		public boolean background = true;
		public float backgroundOpacity = 0.4f;
		public float verticalOffset = 0.5f;
	}

	public static class FlightSettings {
		public boolean enabled = false;
		public double speed = 1.0;
		public boolean hover = false;
		public boolean statusHud = true;
	}

	public static class ReachSettings {
		public boolean enabled = false;
		public double blockReach = 4.5;
		public double entityReach = 3.0;
		public double minReach = 3.0;
		public double maxReach = 10.0;
		public double increment = 0.5;

		public static final double DEFAULT_BLOCK_REACH = 4.5;
		public static final double DEFAULT_ENTITY_REACH = 3.0;
	}

	public static class GuiSettings {
		public float scale = 1.0f;
	}
}
