package me.francisek.client.feature.movement;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.player.PlayerAbilities;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

import me.francisek.client.config.ConfigManager;
import me.francisek.client.config.ModConfig;
import me.francisek.client.feature.Feature;
import me.francisek.client.feature.FeatureManager;
import me.francisek.client.util.ClientUtils;

/**
 * Client-side flight for local single-player testing, layered on top of vanilla's own
 * creative-style flight physics (see class javadoc below for why) rather than a hand-rolled
 * position integrator.
 *
 * <h2>How this works</h2>
 * Enabling this feature temporarily sets {@link PlayerAbilities#allowFlying} and
 * {@link PlayerAbilities#flying} on the local player and pushes the change to the server via
 * {@link ClientPlayerEntity#sendAbilitiesUpdate()} - the exact same mechanism vanilla's own
 * double-tap-space creative flight toggle uses. Movement itself is then handled entirely by
 * Minecraft's existing flight physics (the same code creative and spectator mode already use),
 * which is why it stays smooth or integrates with sprinting/strafing/other mods without this
 * class reimplementing movement integration or touching the player's position directly.
 *
 * <h2>Known limitation</h2>
 * Because the server (the integrated singleplayer server) ultimately owns ability state, a
 * world where cheats are disabled and the player is in Survival may reject or fight the
 * ability change. For reliable local testing, enable cheats on the world (Escape → Open to LAN
 * → Allow Cheats, or set the world's "Allow Cheats" option) or use a Creative-mode world. This
 * is a deliberate boundary, not a bug: this feature does not attempt to spoof or bypass server
 * authority, per the project's safety requirements.
 */
public class Flight extends Feature implements FeatureManager.WorldDependent {

	private final ConfigManager configManager;

	private boolean originalAllowFlying;
	private boolean originalFlying;
	private float originalFlySpeed;
	private boolean capturedOriginalState;

	public Flight(ConfigManager configManager) {
		super("flight", "francisekclient.feature.flight.name", "francisekclient.feature.flight.description", false);
		this.configManager = configManager;
	}

	@Override
	protected void onEnable() {
		ClientPlayerEntity player = ClientUtils.player();
		if (player == null) {
			// No world loaded yet (e.g. toggled from the main menu GUI preview) - the state
			// will be applied the next time tick() runs once a player exists.
			return;
		}
		captureOriginalState(player);
		applyFlightAbilities(player);
	}

	@Override
	protected void onDisable() {
		ClientPlayerEntity player = ClientUtils.player();
		if (player != null && capturedOriginalState) {
			restoreOriginalState(player);
		}
		capturedOriginalState = false;
	}

	@Override
	public void tick() {
		ClientPlayerEntity player = ClientUtils.player();
		if (player == null) {
			return;
		}

		if (!capturedOriginalState) {
			captureOriginalState(player);
			applyFlightAbilities(player);
		}

		ModConfig.FlightSettings settings = configManager.config().flight;
		PlayerAbilities abilities = player.getAbilities();

		// Re-assert flying=true every tick: vanilla clears this automatically when the
		// player touches the ground, which we do not want while this feature is active.
		if (!abilities.flying) {
			abilities.flying = true;
			player.sendAbilitiesUpdate();
		}

		abilities.setFlySpeed((float) (0.05 * settings.speed));

		if (settings.hover) {
			applyHoverMovement(player);
		}
	}

	@Override
	public void renderHud(DrawContext context, RenderTickCounter tickCounter) {
		ModConfig.FlightSettings settings = configManager.config().flight;
		if (!settings.statusHud) {
			return;
		}

		int x = 6;
		int y = 6;
		context.drawTextWithShadow(ClientUtils.client().textRenderer,
				Text.translatable("francisekclient.hud.flight_on"), x, y, 0x55FF55);
		context.drawTextWithShadow(ClientUtils.client().textRenderer,
				Text.translatable("francisekclient.hud.flight_speed", String.format("%.2f", settings.speed)),
				x, y + 10, 0xCCCCCC);
	}

	/**
	 * When "hover" is enabled, vertical drift is cancelled the instant there is no jump/sneak
	 * input, instead of vanilla's default of gently gliding to a stop. Horizontal movement is
	 * left entirely to vanilla's own flight physics either way.
	 */
	private void applyHoverMovement(ClientPlayerEntity player) {
		// "playerInput" is a public field on Input (holding a PlayerInput record), not a
		// method - confirmed against yarn-1.21.11's Input class.
		var input = player.input.playerInput;
		boolean ascending = input.jump();
		boolean descending = input.sneak();

		if (!ascending && !descending) {
			Vec3d velocity = player.getVelocity();
			if (Math.abs(velocity.y) > 1.0e-4) {
				player.setVelocity(velocity.x, 0.0, velocity.z);
			}
		}
	}

	private void captureOriginalState(ClientPlayerEntity player) {
		PlayerAbilities abilities = player.getAbilities();
		originalAllowFlying = abilities.allowFlying;
		originalFlying = abilities.flying;
		originalFlySpeed = abilities.getFlySpeed();
		capturedOriginalState = true;
	}

	private void applyFlightAbilities(ClientPlayerEntity player) {
		PlayerAbilities abilities = player.getAbilities();
		abilities.allowFlying = true;
		abilities.flying = true;
		player.sendAbilitiesUpdate();
	}

	private void restoreOriginalState(ClientPlayerEntity player) {
		PlayerAbilities abilities = player.getAbilities();
		// Never force allowFlying/flying to *false* if the player is genuinely in creative or
		// spectator mode - only undo the change if the value still matches what this feature
		// set, otherwise leave whatever the game itself has since decided.
		abilities.allowFlying = originalAllowFlying;
		abilities.flying = originalFlying;
		abilities.setFlySpeed(originalFlySpeed);
		player.sendAbilitiesUpdate();
	}
}
