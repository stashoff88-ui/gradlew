package me.francisek.client.client;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;

import me.francisek.client.config.ConfigManager;
import me.francisek.client.feature.FeatureManager;

/**
 * Registers the client lifecycle hooks the mod depends on for safe cleanup: disabling
 * world-dependent features (Flight, Reach) on disconnect so no altered player state ever
 * survives into a different world or the main menu, and flushing the config to disk on both
 * disconnect and full client shutdown.
 */
public final class ClientLifecycleHandler {

	private final FeatureManager featureManager;
	private final ConfigManager configManager;

	public ClientLifecycleHandler(FeatureManager featureManager, ConfigManager configManager) {
		this.featureManager = featureManager;
		this.configManager = configManager;
	}

	public void register() {
		ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
			featureManager.disableWorldDependentFeatures();
			configManager.save(true);
		});

		ClientLifecycleEvents.CLIENT_STOPPING.register(client -> configManager.save(true));
	}
}
