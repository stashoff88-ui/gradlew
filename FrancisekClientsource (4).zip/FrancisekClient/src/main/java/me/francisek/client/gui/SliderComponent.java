package me.francisek.client.gui;

import java.util.function.DoubleConsumer;
import java.util.function.DoubleSupplier;
import java.util.function.DoubleUnaryOperator;

import net.minecraft.client.gui.screen.ScreenTexts;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

/**
 * Generic double-range slider used for every numeric setting in the GUI (reach, flight speed,
 * ESP max distance/line width, entity info text scale/opacity, ...). Vanilla's
 * {@link SliderWidget} only knows about a normalized 0..1 {@code value}; this class handles
 * mapping that to and from the real-world range and formatting the label.
 */
public class SliderComponent extends SliderWidget {

	private final double min;
	private final double max;
	private final DoubleConsumer onChange;
	private final LabelFormatter labelFormatter;
	private final DoubleUnaryOperator snap;

	/** Formats the current real (unmapped) value into the text shown on the slider. */
	public interface LabelFormatter {
		Text format(double value);
	}

	public SliderComponent(int x, int y, int width, int height, double min, double max,
			DoubleSupplier initial, DoubleConsumer onChange, double step, LabelFormatter labelFormatter) {
		// ScreenTexts.EMPTY replaces Text.empty() (see KeybindComponent for the same fix); the
		// real label is set immediately below via updateMessage(), so this initial value is only
		// ever shown for a single frame before construction finishes.
		super(x, y, width, height, ScreenTexts.EMPTY, toNormalized(initial.getAsDouble(), min, max));
		this.min = min;
		this.max = max;
		this.onChange = onChange;
		this.labelFormatter = labelFormatter;
		this.snap = step > 0 ? v -> Math.round(v / step) * step : v -> v;
		updateMessage();
	}

	private static double toNormalized(double real, double min, double max) {
		if (max <= min) {
			return 0.0;
		}
		return (real - min) / (max - min);
	}

	private double realValue() {
		return snap.applyAsDouble(min + (max - min) * this.value);
	}

	@Override
	protected void updateMessage() {
		setMessage(labelFormatter.format(realValue()));
	}

	@Override
	protected void applyValue() {
		onChange.accept(realValue());
	}
}
