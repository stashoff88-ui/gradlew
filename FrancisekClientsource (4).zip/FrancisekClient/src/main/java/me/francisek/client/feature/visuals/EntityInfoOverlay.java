package me.francisek.client.feature.visuals;

import java.util.ArrayList;
import java.util.List;

import org.joml.Quaternionf;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldExtractionContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

import me.francisek.client.config.ConfigManager;
import me.francisek.client.config.ModConfig;
import me.francisek.client.feature.Feature;
import me.francisek.client.rendering.WorldTextRenderer;
import me.francisek.client.util.ClientUtils;
import me.francisek.client.util.EntityUtils;
import me.francisek.client.util.MathUtils;

/**
 * Displays a small, camera-facing name / health / distance block above nearby living
 * entities. Shares {@link WorldTextRenderer} with every other text-drawing code path in the
 * mod rather than maintaining its own rendering pipeline.
 *
 * <p>Split across the extraction/draw phases exactly like {@link EntityESP}: {@link #extractWorld}
 * gathers the text lines and camera-relative position per entity plus a snapshot of the
 * camera's rotation (needed for billboarding, and only available during extraction);
 * {@link #renderWorld} replays that snapshot.
 */
public class EntityInfoOverlay extends Feature {

	/** Full-bright packed light value, matching what vanilla uses for entity nameplates. */
	private static final int FULL_BRIGHT = 0xF000F0;

	private final ConfigManager configManager;
	private volatile List<InfoEntry> snapshot = List.of();
	private volatile Quaternionf cameraRotation = new Quaternionf();

	public EntityInfoOverlay(ConfigManager configManager) {
		super("entity_info", "francisekclient.feature.entity_info.name", "francisekclient.feature.entity_info.description", false);
		this.configManager = configManager;
	}

	private record InfoEntry(Vec3d relativePos, List<Text> lines) {
	}

	@Override
	public void extractWorld(WorldExtractionContext context) {
		ModConfig.EntityInfoSettings settings = configManager.config().entityInfo;
		PlayerEntity self = ClientUtils.player();
		Camera camera = context.camera();
		Vec3d cameraPos = camera.getCameraPos();
		float tickDelta = context.tickCounter().getTickProgress(true);
		double maxDistanceSq = settings.maxDistance * settings.maxDistance;

		this.cameraRotation = new Quaternionf(camera.getRotation());

		List<InfoEntry> entries = new ArrayList<>();
		for (Entity entity : context.world().getEntities()) {
			if (!(entity instanceof LivingEntity living) || entity == self || !entity.isAlive()) {
				continue;
			}

			double distanceSq = self.squaredDistanceTo(entity);
			if (distanceSq > maxDistanceSq) {
				continue;
			}

			List<Text> lines = buildLines(settings, living, distanceSq);
			if (lines.isEmpty()) {
				continue;
			}

			Vec3d relativePos = EntityUtils.interpolatedPosition(entity, tickDelta)
					.add(0, entity.getHeight() + settings.verticalOffset, 0)
					.subtract(cameraPos);

			entries.add(new InfoEntry(relativePos, lines));
		}

		this.snapshot = entries;
	}

	@Override
	public void renderWorld(WorldRenderContext context) {
		ModConfig.EntityInfoSettings settings = configManager.config().entityInfo;
		var matrices = context.matrices();
		var consumers = context.consumers();
		if (matrices == null || consumers == null) {
			return;
		}

		for (InfoEntry entry : snapshot) {
			WorldTextRenderer.drawLines(matrices, consumers, cameraRotation, entry.relativePos(), entry.lines(),
					settings.textScale, settings.background, settings.backgroundOpacity, FULL_BRIGHT);
		}
	}

	private static List<Text> buildLines(ModConfig.EntityInfoSettings settings, LivingEntity living, double distanceSq) {
		List<Text> lines = new ArrayList<>(3);

		if (settings.showName) {
			lines.add(living.getDisplayName());
		}
		if (settings.showHealth) {
			double health = MathUtils.roundTo(living.getHealth(), 1);
			double maxHealth = MathUtils.roundTo(living.getMaxHealth(), 1);
			lines.add(Text.translatable("francisekclient.format.literal", String.format("❤ %s / %s", trimTrailingZero(health), trimTrailingZero(maxHealth))));
		}
		if (settings.showDistance) {
			double distance = MathUtils.roundTo(Math.sqrt(distanceSq), 1);
			lines.add(Text.translatable("francisekclient.format.literal", String.format("%sm", trimTrailingZero(distance))));
		}

		return lines;
	}

	private static String trimTrailingZero(double value) {
		if (value == Math.rint(value)) {
			return String.valueOf((long) value);
		}
		return String.valueOf(value);
	}
}
