# Francisek Client

A client-side Fabric utility mod for **Minecraft Java Edition 1.21.11**, built for local
single-player testing and experimentation. It is a genuine Fabric mod — not a Bukkit / Spigot /
Paper / Forge / NeoForge plugin — and it never runs, requires, or talks to a dedicated server.

| | |
|---|---|
| Minecraft | `1.21.11` |
| Mod Loader | Fabric Loader `0.18.1`+ |
| Fabric API | `0.141.2+1.21.11` |
| Mappings | Yarn `1.21.11+build.4` |
| Loom (dev tool) | `1.17.12` |
| Java | `21` |
| Gradle | `9.5.0`+ (min. `9.4`, required by Loom 1.17) |
| Mod ID | `francisekclient` |
| License | MIT |

> **This mod is scoped to single-player / local testing.** It does not send custom network
> packets, does not attempt to bypass server anti-cheat, does not spoof server-side state, and
> collects no telemetry of any kind. See [Safety boundary](#safety-boundary) below.

---

## Build status (read this first)

This project was generated and written in a sandboxed cloud environment that has **no network
access** to Mojang's game files, the Fabric Maven repository, or the Gradle plugin portal. That
means the source code below was written and hand-verified against Fabric/Yarn API
documentation, but it was **not actually compiled or run** in this environment.

```
SOURCE CREATED:   YES  — every file listed below is a complete, non-placeholder implementation
COMPILED:         NO   — no network access to download Minecraft, Yarn mappings or Fabric API
JAR VERIFIED:     NO   — no compiled JAR exists to inspect
RUNTIME TESTED:   NO   — Minecraft was never launched
```

**No part of this is fabricated as "passing."** The honest state is: complete source, unbuilt.

### API verification pass

After the initial draft, every non-trivial Minecraft/Fabric API call in this project was
individually re-checked against the real `yarn-1.21.11+build.4` and version-pinned `fabric-api`
Javadoc (not a nearby version) and fixed where it disagreed. Two rounds of this caught real
mistakes, all now corrected in the source.

**Round 2 — the world-rendering API was from an older Fabric API version.** The single biggest
finding: Fabric API's world-render event shape changed for Minecraft **1.21.10** (one version
before this mod's 1.21.11 target) to match Minecraft's own render-thread rewrite, and the first
draft used the pre-1.21.10 shape throughout. Confirmed directly against
`fabric-api-0.137.0+1.21.10` Javadoc (the earliest version this actually applies to) and fixed:

- `net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext` **no longer exists at that
  package path** — it moved to `net.fabricmc.fabric.api.client.rendering.v1.world`, alongside a
  new `WorldExtractionContext` (see [Rendering](#rendering)). `Feature`, `FeatureManager`,
  `FrancisekClient`, `EntityESP`, `EntityInfoOverlay`, `RenderUtils`, `BoxRenderer`,
  `OutlineRenderer`, and `WorldTextRenderer` were all restructured around the resulting
  two-phase extraction/draw split — this is a real architectural change, not just an import fix.
- The draw-phase context's method is `matrices()`, not the old `matrixStack()`.
- The draw-phase context no longer exposes `camera()`, `world()`, `tickCounter()`,
  `positionMatrix()`, or `projectionMatrix()` at all — those are only available on the new
  extraction-phase context, which is why every camera-relative computation (box bounds, text
  billboard rotation) now happens in each feature's `extractWorld()` instead of `renderWorld()`.
- `RenderSystem.disableDepthTest()`/`enableDepthTest()` could not be confirmed to still exist
  for 1.21.11 (no depth-test methods turned up on `RenderSystem` in the yarn-1.21.11 Javadoc, in
  line with the pipeline-state consolidation the rendering rewrite is doing generally), so ESP's
  "see through walls" effect was rebuilt on `RenderLayer.getDebugQuads()` — a real, confirmed,
  already-through-walls vanilla layer — instead of calling an API that may not exist.

**Round 1 — four smaller Yarn-naming mistakes**, also confirmed and fixed:

1. **`VertexConsumer` method names** (`rendering/BoxRenderer.java`, `rendering/OutlineRenderer.java`)
   — Yarn 1.21.11 kept the classic `vertex(matrix, x, y, z).color(argb).normal(nx, ny, nz)`
   names; it did **not** adopt Mojang's own `addVertex()`/`setColor()`/`setNormal()` renames
   (those only apply if you're building against official Mojang mappings, not Yarn). There is
   also no `.next()`/`.endVertex()` call anymore — the buffer finalizes each vertex
   automatically.
2. **`Camera.getPos()` doesn't exist** — the real method is `Camera.getCameraPos()`.
3. **`Input.playerInput` is a field, not a method** (`feature/movement/Flight.java`) — it's
   `player.input.playerInput.jump()`, not `player.input.playerInput().jump()`.
4. **`KeyBinding`'s category parameter changed type** (`keybind/ModKeybindings.java`) — since
   the 1.21.2+ key binding refactor it takes a `KeyBinding.Category` (created via
   `KeyBinding.Category.create(Identifier)`), not a raw translation-key `String`. The category's
   display name is now looked up via the `key.category.<namespace>.<path>` translation key
   convention, updated in the lang file accordingly.

Confirmed and unchanged after both rounds: `RenderTickCounter.getTickProgress`,
`EntityAttributes.BLOCK_INTERACTION_RANGE`/`ENTITY_INTERACTION_RANGE`, `PlayerAbilities` fields,
`ClientPlayerEntity.sendAbilitiesUpdate`, `HudElementRegistry.addLast` + the `HudElement`
functional interface (still at `...rendering.v1.hud`, unaffected by the world-render change),
`Screen.renderBackground`, `DrawContext.fill`/`drawBorder`/`drawTextWithShadow`,
`MatrixStack.Entry.getPositionMatrix`, `ClientWorld.getEntities`,
`LivingEntity.getAttributeInstance`/`getHealth`/`getMaxHealth`, `RenderLayer.getLines`/
`getDebugQuads`, and the `ButtonWidget`/`CheckboxWidget`/`SliderWidget` builder/constructor
shapes used in `gui/`.

This is still not a substitute for an actual compile: it verifies each call against
documentation, not the whole program against a real compiler, so a first `./gradlew build` may
still turn up something small — most likely either a `CheckboxWidget.Builder` chain detail (the
one widget builder whose full method-by-method signatures could not be individually confirmed),
or a further detail of the `WorldRenderContext`/`WorldExtractionContext` shape specific to the
`0.141.2+1.21.11` Fabric API build, since no Javadoc was published for that exact patch version
and `0.137.0+1.21.10` (a real, adjacent, and — per the 1.21.11 announcement — API-compatible
version) was used as the closest verifiable stand-in. Building it is expected to be a normal
`./gradlew build` on a machine with internet access (see [Building](#building)) — treat
compilation as unverified until that has actually been run and its output inspected.

The Gradle wrapper's `gradlew` / `gradlew.bat` scripts and `gradle-wrapper.properties` are
included and correctly pinned to Gradle `9.5.0`, but **`gradle/wrapper/gradle-wrapper.jar` (the
small bootstrap binary) could not be generated**, because generating it requires Gradle to
verify the distribution URL over the network. This is a one-time fix — see
[Building](#building).

---

## Installation

1. Install **Minecraft Java Edition 1.21.11** through the official Minecraft Launcher.
2. Install **Fabric Loader** for `1.21.11` using the [Fabric installer](https://fabricmc.net/use/).
3. Download **Fabric API** build `0.141.2+1.21.11` (or newer for 1.21.11) from Modrinth or
   CurseForge and place it in your `mods` folder.
4. Build this project (see [Building](#building)) to produce
   `francisekclient-1.0.0.jar`, and place it in the same `mods` folder.
5. Launch the `fabric-loader-1.21.11` profile from the Minecraft Launcher.

Only the Fabric Loader / Fabric API versions above were actually checked against Fabric's
official 1.21.11 support announcement at the time this project was written — always confirm the
current recommended versions at [fabricmc.net](https://fabricmc.net/) before installing, since
patch releases ship frequently.

---

## Building

From a machine with normal internet access:

```
git clone <this repository>
cd FrancisekClient
./gradlew build
```

The remapped mod jar is written to `build/libs/francisekclient-1.0.0.jar`.

**If `./gradlew` fails immediately with a wrapper/class-not-found error**, the bundled wrapper
jar is missing (see [Build status](#build-status-read-this-first) above). Fix it once with
either of:

```
# Using any locally installed Gradle 8+:
gradle wrapper --gradle-version 9.5.0

# Or skip the wrapper entirely and build with a local Gradle 9.4+ install:
gradle build
```

Useful tasks:

```
./gradlew build       # compile + test + package the mod jar
./gradlew runClient   # launch a development Minecraft client with the mod loaded
./gradlew clean       # remove build output
```

### Development setup

Import the project into IntelliJ IDEA (recommended) or another IDE with Gradle support. Loom
will download and deobfuscate Minecraft, generate sources, and set up run configurations
automatically on first import/sync — this requires the same network access noted above.

---

## Features

### Entity ESP (`VISUALS` category)

Renders bounding boxes, outlines, or a translucent "glow" fill on nearby living entities,
visible through terrain. Categories (Players, Hostile, Passive, Neutral, Villagers, Other) are
independently toggleable and colorable, including alpha. See
[`util/EntityUtils.java`](src/main/java/me/francisek/client/util/EntityUtils.java) for the
documented classification rules — Minecraft has no single "faction" API, so Hostile/Neutral/
Passive is a deliberate, documented heuristic (`Monster`, `Angerable`, `AnimalEntity`).

Settings: Enabled, Render Mode (Bounding Box / Outline / Glow), per-category toggles, Maximum
Distance, Line Width, per-category color (with alpha).

Rendering uses interpolated entity positions (`Entity#getLerpedPos`) every frame to avoid
jitter, and only iterates entities the client world has already loaded — no world/chunk
scanning of any kind.

### Entity Info (`VISUALS` category)

A small camera-facing text block above nearby entities: name, current/max health, and distance.
Settings: Enabled, Show Name/Health/Distance, Maximum Distance, Text Scale, Background,
Background Opacity, Vertical Offset. Shares the same `WorldTextRenderer` as every other
in-world text in the mod.

### Flight (`MOVEMENT` category)

Client-side flight for local testing, built on top of vanilla's own creative-style flight
physics rather than a hand-rolled position integrator — see the class-level Javadoc in
[`Flight.java`](src/main/java/me/francisek/client/feature/movement/Flight.java) for exactly how
and why. Settings: Enabled, Speed, Hover, Status HUD. Disabling the feature restores the
player's original `allowFlying` / `flying` / `flySpeed` state; it never leaves altered movement
state behind, and is automatically disabled on disconnect/world change.

**Known limitation:** in a Survival-mode world with cheats disabled, the integrated server may
reject the ability change. Enable cheats on the world, or use Creative mode, for reliable
behaviour — this mod does not attempt to force it through server-authoritative checks.

### Reach (`MOVEMENT` category)

Adjusts the local player's block and entity interaction range. Implemented via the vanilla
`EntityAttributes.BLOCK_INTERACTION_RANGE` / `ENTITY_INTERACTION_RANGE` attributes introduced in
1.20.5 — the same mechanism any reach-modifying enchantment or effect uses, so **no mixin or
packet manipulation of any kind is used or needed**. Settings: Enabled, Current/Default reach,
Minimum/Maximum reach, Increment, Reset.

---

## Controls

| Action | Default key | Configurable |
|---|---|---|
| Open Click GUI | Right Shift | Yes — in-game via the GUI's keybind selector, or vanilla's Controls screen |
| Toggle Flight | G | Yes — same as above |

Both bindings are registered as ordinary Fabric `KeyBinding`s, so they participate in vanilla's
own key-conflict detection and are persisted automatically in `options.txt` — this mod does not
maintain a second, competing copy of keybind state.

---

## Configuration

Settings are stored at `config/francisekclient.json` (JSON, human-editable) and are also
editable live from the in-game Click GUI. Loading is defensive: a missing file, corrupted JSON,
missing fields (e.g. after upgrading to a version with new settings), or out-of-range values are
all repaired with sensible clamped defaults rather than crashing the client — see
[`ConfigValidator.java`](src/main/java/me/francisek/client/config/ConfigValidator.java). Saves
are rate-limited (at most once every 2 seconds) while the GUI is open to avoid disk-write spam
from slider dragging, and are always flushed immediately on world disconnect and client
shutdown.

Keybindings are **not** duplicated into this file — see [Controls](#controls).

---

## Architecture

```
me.francisek.client
├── FrancisekClient            entrypoint; wires everything together
├── client/                    tick + lifecycle event handlers
├── feature/                   Feature base class, FeatureManager registry
│   ├── visuals/                EntityESP, EntityInfoOverlay
│   └── movement/                Flight, ReachAdjustment
├── config/                    ModConfig (data), ConfigManager (I/O), ConfigSerializer (Gson),
│                               ConfigValidator (sanitization)
├── gui/                       ClickGuiScreen, SettingsScreen, CategoryPanel, ModuleButton,
│                               ToggleComponent, SliderComponent, ColorPickerComponent,
│                               KeybindComponent
├── rendering/                 RenderUtils, BoxRenderer, OutlineRenderer, WorldTextRenderer,
│                               ColorUtils
├── keybind/                   ModKeybindings
└── util/                      EntityUtils, MathUtils, ClientUtils, TimeUtils
```

A new feature only needs to: extend `Feature`, implement whichever of `tick()` /
`renderWorld()` / `renderHud()` it needs, add a settings group to `ModConfig`, register itself
in `FrancisekClient.onInitializeClient()`, and add itself to a `CategoryPanel`. No other class
needs to change.

### Rendering

World rendering is split across Fabric API's **extraction/draw** event pair, introduced for
Minecraft 1.21.10 to mirror Minecraft's own render rewrite and reintroduced under
`net.fabricmc.fabric.api.client.rendering.v1.world` (an earlier draft of this project used the
pre-1.21.10, single-phase `WorldRenderContext` API from `...rendering.v1` directly — that
package/class shape no longer exists for 1.21.10+ and has been replaced throughout):

- **`WorldRenderEvents.END_EXTRACTION`** fires first, with a `WorldExtractionContext` that has
  live access to the camera, client world and tick counter. Every feature's `extractWorld()`
  does all of its entity iteration, classification, distance culling, and camera-relative math
  here, and stores the result as one small immutable snapshot (a `List` of a private `record`).
- **`WorldRenderEvents.AFTER_ENTITIES`** fires next, with a `WorldRenderContext` that only
  exposes a matrix stack (`matrices()`) and vertex consumer provider (`consumers()`) — no
  camera, world, or tick counter. Every feature's `renderWorld()` just replays the snapshot
  `extractWorld()` built a moment earlier into `BoxRenderer` / `OutlineRenderer` /
  `WorldTextRenderer`.

`RenderUtils` centralises the camera-relative math: `toCameraRelative` (extraction-phase,
subtracts the camera position) and `withRelativeSpace` (draw-phase, pushes/pops the matrix
stack by an already-relative offset, guaranteed even on exception via `try`/`finally`). ESP's
"see through walls" look comes from vanilla's own `rendertype_debug_quads` render layer
(`RenderLayer.getDebugQuads()`, via `OutlineRenderer`) rather than a manually toggled global
depth-test flag — this project could not confirm a still-existing `RenderSystem` depth-test
toggle for 1.21.11 (that kind of global GL state looks to have been folded into per-pipeline
state as part of Minecraft's broader rendering rewrite), so it deliberately relies on an
already-through-walls vanilla layer instead of calling an unverified API.

### Mixins

**This mod uses zero mixins.** Every feature is implemented through public Fabric API or
existing vanilla APIs (attribute instances, player abilities, key bindings, render events) —
per the project's own "avoid mixins whenever a hook already exists" principle, no
interaction/raycast override was needed once reach was correctly implemented via
`EntityAttributes` instead of a hardcoded distance.

### Performance

- ESP and Entity Info both iterate only `ClientWorld#getEntities()` (already-loaded entities,
  no chunk/world scanning) once per frame, with an early distance-squared cull before any
  rendering math or category classification runs.
- No collections are allocated per frame; rendering writes directly into the vertex consumer
  buffers Fabric already provides for that frame.
- Config saves are rate-limited (see [Configuration](#configuration)).
- All string formatting for Entity Info happens only for entities that already passed the
  distance and category filters, not for every loaded entity.

---

## Safety boundary

- No custom network packets. No server-side logic is touched or assumed.
- No anti-cheat bypass, packet spoofing, or exploit chains of any kind.
- No telemetry, analytics, remote logging, or external HTTP requests — the mod is 100% local.
- Reach adjustment uses the same vanilla attribute system any legitimate gameplay effect uses;
  it does not touch raycasting, interaction packets, or server validation.
- Flight relies on the client and (singleplayer) integrated server's own existing ability-sync
  mechanism, the same one vanilla's creative-mode flight toggle uses; it does not spoof or
  forge packets.

---

## Testing status

| Area | Status |
|---|---|
| Compilation | **Not verified** — see [Build status](#build-status-read-this-first) |
| JAR validation | **Not verified** — no jar was produced in this environment |
| Runtime (in-game) testing | **Not verified** — Minecraft was never launched |
| Static review (structure, API cross-checks, brace/package sanity) | Done — see below |

What *was* done in this environment: every class was written against Fabric/Yarn 1.21.11
documentation fetched during development (package layout, `WorldRenderContext` members,
`RenderTickCounter.getTickProgress`, `EntityAttributes.BLOCK_INTERACTION_RANGE` /
`ENTITY_INTERACTION_RANGE`, `PlayerAbilities` fields, `ClientPlayerEntity.sendAbilitiesUpdate`,
`HudElementRegistry.addLast`, `Screen.renderBackground`, among others were each individually
confirmed against `yarn-1.21.11` or current `fabric-api` Javadoc), plus an automated
brace/parenthesis-balance and package-declaration check across all 31 Java files (all passed).
That is meaningfully short of an actual compile — please treat this as a careful first build,
not a finished/shipped release, and expect to fix a handful of small API-naming issues on the
first real `./gradlew build`.

---

## Known limitations

- Flight may be rejected by the integrated server in a Survival world with cheats disabled (see
  [Flight](#flight-movement-category)).
- The Hostile / Neutral / Passive ESP split is a heuristic, not an authoritative Minecraft
  concept — see `EntityUtils.classify`.
- The color picker uses four channel sliders (A/R/G/B) rather than a hue/saturation wheel, to
  keep the widget implementation simple and low-risk.
- The "Dropdown" control for ESP render mode is implemented as a cycle-on-click button rather
  than a full popup list, for the same reason.
- ESP's "Bounding Box" and "Outline" wireframe modes are depth-tested (hidden behind terrain),
  matching vanilla's own hitbox debug lines; only "Glow" mode draws through walls, via vanilla's
  debug-quads layer. See [Rendering](#rendering) for why this project didn't force wireframe
  boxes through walls too, given it couldn't confirm a global depth-test toggle still exists.
- The `lineWidth` ESP setting is accepted and stored but not currently applied to rendering —
  `RenderLayer.getLines()` doesn't expose a width parameter the way the line-strip variant does;
  see the comment in `BoxRenderer.drawWireframe`.
- This build has not been compiled or runtime-tested in the environment that produced it (see
  above).

---

## File list

See the [Architecture](#architecture) tree above for the Java source layout. Project root also
contains `build.gradle`, `settings.gradle`, `gradle.properties`, `gradlew` / `gradlew.bat`,
`gradle/wrapper/gradle-wrapper.properties`, `LICENSE` (MIT), and
`src/main/resources/fabric.mod.json`, `.../assets/francisekclient/{icon.png,lang/en_us.json}`.
